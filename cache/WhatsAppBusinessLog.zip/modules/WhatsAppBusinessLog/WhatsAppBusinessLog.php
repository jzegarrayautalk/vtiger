<?php
/*+**********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 ************************************************************************************/

include_once 'modules/Vtiger/CRMEntity.php';

class WhatsAppBusinessLog extends Vtiger_CRMEntity {
	var $table_name = 'vtiger_whatsappbusinesslog';
	var $table_index= 'whatsappbusinesslogid';

	/**
	 * Mandatory table for supporting custom fields.
	 */
	var $customFieldTable = Array('vtiger_whatsappbusinesslogcf', 'whatsappbusinesslogid');

	/**
	 * Mandatory for Saving, Include tables related to this module.
	 */
	var $tab_name = Array('vtiger_crmentity', 'vtiger_whatsappbusinesslog', 'vtiger_whatsappbusinesslogcf');

	/**
	 * Mandatory for Saving, Include tablename and tablekey columnname here.
	 */
	var $tab_name_index = Array(
		'vtiger_crmentity' => 'crmid',
		'vtiger_whatsappbusinesslog' => 'whatsappbusinesslogid',
		'vtiger_whatsappbusinesslogcf'=>'whatsappbusinesslogid');

	/**
	 * Mandatory for Listing (Related listview)
	 */
	var $list_fields = Array (
		/* Format: Field Label => Array(tablename, columnname) */
		// tablename should not have prefix 'vtiger_'
		'WhatsAppBusinessLog No' => Array('whatsapplog', 'whatsapplog_no'),
		'Assigned To' => Array('crmentity','smownerid')
	);
	var $list_fields_name = Array (
		/* Format: Field Label => fieldname */
		'WhatsAppBusinessLog No' => 'whatsapplog_no',
		'Assigned To' => 'assigned_user_id',
	);

	// Make the field link to detail view
	var $list_link_field = 'whatsapplog_no';

	// For Popup listview and UI type support
	var $search_fields = Array(
		/* Format: Field Label => Array(tablename, columnname) */
		// tablename should not have prefix 'vtiger_'
		'WhatsAppBusinessLog No' => Array('whatsapplog', 'whatsapplog_no'),
		'Assigned To' => Array('vtiger_crmentity','assigned_user_id'),
	);
	var $search_fields_name = Array (
		/* Format: Field Label => fieldname */
		'WhatsAppBusinessLog No' => 'whatsapplog_no',
		'Assigned To' => 'assigned_user_id',
	);

	// For Popup window record selection
	var $popup_fields = Array ('whatsapplog_no');

	// For Alphabetical search
	var $def_basicsearch_col = 'whatsapplog_no';

	// Column value to use on detail view record text display
	var $def_detailview_recname = 'whatsapplog_no';

	// Used when enabling/disabling the mandatory fields for the module.
	// Refers to vtiger_field.fieldname values.
	var $mandatory_fields = Array('whatsapplog_no','assigned_user_id');

	var $default_order_by = 'whatsapplog_no';
	var $default_sort_order='ASC';

	/**
	* Invoked when special actions are performed on the module.
	* @param String Module name
	* @param String Event Type
	*/
	function vtlib_handler($moduleName, $eventType) {
		global $adb;
 		if($eventType == 'module.postinstall') {
			$this->insertWSEntity();
			// TODO Handle actions after this module is installed.
		} else if($eventType == 'module.disabled') {
			$this->insertWSEntity();
			// TODO Handle actions before this module is being uninstalled.
		} else if($eventType == 'module.preuninstall') {
			$this->insertWSEntity();
			// TODO Handle actions when this module is about to be deleted.
		} else if($eventType == 'module.preupdate') {
			$this->insertWSEntity();
			// TODO Handle actions before this module is updated.
		} else if($eventType == 'module.postupdate') {
			$this->insertWSEntity();
			// TODO Handle actions after this module is updated.
		}
 	}
	private function insertWSEntity() {
        $adb = PearDatabase::getInstance();
        $getentity =$adb->pquery("SELECT * FROM vtiger_ws_entity WHERE name = ?", array('WhatsAppBusinessLog'));
		if($adb->num_rows($getentity) != 1){
			$seq = $adb->pquery("SELECT id FROM vtiger_ws_entity order by id desc limit 0,1", array());
			$id = $adb->query_result($seq, 0, 'id');
			$seq = $id + 1;
			$adb->pquery("INSERT INTO vtiger_ws_entity (id, name, handler_path, handler_class, ismodule) VALUES ($seq, 'WhatsAppBusinessLog', 'include/Webservices/VtigerModuleOperation.php', 'VtigerModuleOperation', '1')");
			$adb->pquery("UPDATE vtiger_ws_entity_seq SET id = ?",$seq);
		}
	}
}