<?php
/*+**********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 ************************************************************************************/

include_once 'modules/Vtiger/CRMEntity.php';

class WhatsAppBusinessTemplates extends Vtiger_CRMEntity {
	var $table_name = 'vtiger_ctwhatsappbusinesstemplates';
	var $table_index= 'ctwhatsappbusinesstemplatesid';

	/**
	 * Mandatory table for supporting custom fields.
	 */
	var $customFieldTable = Array('vtiger_ctwhatsappbusinesstemplatescf', 'ctwhatsappbusinesstemplatesid');

	/**
	 * Mandatory for Saving, Include tables related to this module.
	 */
	var $tab_name = Array('vtiger_crmentity', 'vtiger_ctwhatsappbusinesstemplates', 'vtiger_ctwhatsappbusinesstemplatescf');

	/**
	 * Mandatory for Saving, Include tablename and tablekey columnname here.
	 */
	var $tab_name_index = Array(
		'vtiger_crmentity' => 'crmid',
		'vtiger_ctwhatsappbusinesstemplates' => 'ctwhatsappbusinesstemplatesid',
		'vtiger_ctwhatsappbusinesstemplatescf'=>'ctwhatsappbusinesstemplatesid');

	/**
	 * Mandatory for Listing (Related listview)
	 */
	var $list_fields = Array (
		/* Format: Field Label => Array(tablename, columnname) */
		// tablename should not have prefix 'vtiger_'
		'ctwhatsappbusinesstemplates No' => Array('ctwhatsappbusinesstemplates', 'ctwhatsappbusinesstemplates_no'),
		'Assigned To' => Array('crmentity','smownerid')
	);
	var $list_fields_name = Array (
		/* Format: Field Label => fieldname */
		'ctwhatsappbusinesstemplates No' => 'ctwhatsappbusinesstemplates_no',
		'Assigned To' => 'assigned_user_id',
	);

	// Make the field link to detail view
	var $list_link_field = 'ctwhatsappbusinesstemplates_no';

	// For Popup listview and UI type support
	var $search_fields = Array(
		/* Format: Field Label => Array(tablename, columnname) */
		// tablename should not have prefix 'vtiger_'
		'ctwhatsappbusinesstemplates No' => Array('ctwhatsappbusinesstemplates', 'ctwhatsappbusinesstemplates_no'),
		'Assigned To' => Array('vtiger_crmentity','assigned_user_id'),
	);
	var $search_fields_name = Array (
		/* Format: Field Label => fieldname */
		'ctwhatsappbusinesstemplates No' => 'ctwhatsappbusinesstemplates_no',
		'Assigned To' => 'assigned_user_id',
	);

	// For Popup window record selection
	var $popup_fields = Array ('ctwhatsappbusinesstemplates_no');

	// For Alphabetical search
	var $def_basicsearch_col = 'ctwhatsappbusinesstemplates_no';

	// Column value to use on detail view record text display
	var $def_detailview_recname = 'ctwhatsappbusinesstemplates_no';

	// Used when enabling/disabling the mandatory fields for the module.
	// Refers to vtiger_field.fieldname values.
	var $mandatory_fields = Array('ctwhatsappbusinesstemplates_no','assigned_user_id');

	var $default_order_by = 'ctwhatsappbusinesstemplates_no';
	var $default_sort_order='ASC';

	/**
	* Invoked when special actions are performed on the module.
	* @param String Module name
	* @param String Event Type
	*/
	function vtlib_handler($moduleName, $eventType) {
		global $adb;
 		if($eventType == 'module.postinstall') {
 			// TODO Handle actions after this module is installed.
 			$this->insertWSEntity();
 			$this->insertLanguageRecord();

		} else if($eventType == 'module.disabled') {
			// TODO Handle actions before this module is being uninstalled.
		} else if($eventType == 'module.preuninstall') {
			// TODO Handle actions when this module is about to be deleted.
			$this->insertWSEntity();
		} else if($eventType == 'module.preupdate') {
			// TODO Handle actions before this module is updated.
			$this->insertWSEntity();
		} else if($eventType == 'module.postupdate') {
			// TODO Handle actions after this module is updated.
			$this->insertWSEntity();
			$this->insertLanguageRecord();
		}
 	}

 	private function insertWSEntity() {
        $adb = PearDatabase::getInstance();
        $getentity =$adb->pquery("SELECT * FROM vtiger_ws_entity WHERE name = ?", array('WhatsAppBusinessTemplates'));
		if($adb->num_rows($getentity) != 1){
			$seq = $adb->pquery("SELECT id FROM vtiger_ws_entity order by id desc limit 0,1", array());
			$id = $adb->query_result($seq, 0, 'id');
			$seq = $id + 1;
			$adb->pquery("INSERT INTO vtiger_ws_entity (id, name, handler_path, handler_class, ismodule) VALUES ($seq, 'WhatsAppBusinessTemplates', 'include/Webservices/VtigerModuleOperation.php', 'VtigerModuleOperation', '1')");
			$adb->pquery("UPDATE vtiger_ws_entity_seq SET id = ?",$seq);
		}
	}

	function insertLanguageRecord(){
		global $adb;
		$adb->pquery("INSERT INTO 'ctwhatsapp_template_languages' ('id', 'language_name', 'language_code') VALUES (1, 'Afrikaans', 'af'),
					(2, 'Albanian', 'sq'),
					(3, 'Arabic', 'ar'),
					(4, 'Azerbaijani', 'az'),
					(5, 'Bengali', 'bn'),
					(6, 'Bulgarian', 'bg'),
					(7, 'Catalan', 'ca'),
					(8, 'Chinese (CHN)', 'zh_CN'),
					(9, 'Chinese (HKG)', 'zh_HK'),
					(10, 'Chinese (TAI)', 'zh_TW'),
					(11, 'Croatian', 'hr'),
					(12, 'Czech', 'cs'),
					(13, 'Danish', 'da'),
					(14, 'Dutch', 'nl'),
					(15, 'English', 'en'),
					(16, 'English (UK)', 'en_GB'),
					(17, 'English (US)', 'en_US'),
					(18, 'Estonian', 'et'),
					(19, 'Filipino', 'fil'),
					(20, 'Finnish', 'fi'),
					(21, 'French', 'fr'),
					(22, 'Georgian', 'ka'),
					(23, 'German', 'de'),
					(24, 'Greek', 'el'),
					(25, 'Gujarati', 'gu'),
					(26, 'Hausa', 'ha'),
					(27, 'Hebrew', 'he'),
					(28, 'Hindi', 'hi'),
					(29, 'Hungarian', 'hu'),
					(30, 'Indonesian', 'id'),
					(31, 'Irish', 'ga'),
					(32, 'Italian', 'it'),
					(33, 'Japanese', 'ja'),
					(34, 'Kannada', 'kn'),
					(35, 'Kazakh', 'kk'),
					(36, 'Kinyarwanda', 'rw_RW'),
					(37, 'Korean', 'ko'),
					(38, 'Kyrgyz (Kyrgyzstan)', 'ky_KG'),
					(39, 'Lao', 'lo'),
					(40, 'Latvian', 'lv'),
					(41, 'Lithuanian', 'lt'),
					(42, 'Macedonian', 'mk'),
					(43, 'Malay', 'ms'),
					(44, 'Malayalam', 'ml'),
					(45, 'Marathi', 'mr'),
					(46, 'Norwegian', 'nb'),
					(47, 'Persian', 'fa'),
					(48, 'Polish', 'pl'),
					(49, 'Portuguese (BR)', 'pt_BR'),
					(50, 'Portuguese (POR)', 'pt_PT'),
					(51, 'Punjabi', 'pa'),
					(52, 'Romanian', 'ro'),
					(53, 'Russian', 'ru'),
					(54, 'Serbian', 'sr'),
					(55, 'Slovak', 'sk'),
					(56, 'Slovenian', 'sl'),
					(57, 'Spanish', 'es'),
					(58, 'Spanish (ARG)', 'es_AR'),
					(59, 'Spanish (SPA)', 'es_ES'),
					(60, 'Spanish (MEX)', 'es_MX'),
					(61, 'Swahili', 'sw'),
					(62, 'Swedish', 'sv'),
					(63, 'Tamil', 'ta'),
					(64, 'Telugu', 'te'),
					(65, 'Thai', 'th'),
					(66, 'Turkish', 'tr'),
					(67, 'Ukrainian', 'uk'),
					(68, 'Urdu', 'ur'),
					(69, 'Uzbek', 'uz'),
					(70, 'Vietnamese', 'vi'),
					(71, 'Zulu', 'zu')");
	}//end of function

 	function save_module($module){
		$this->insertIntoAttachment($this->id,$module);
	}

	/**
	 *      This function is used to add the vtiger_attachments. This will call the function uploadAndSaveFile which will upload the attachment into the server and save that attachment information in the database.
	 *      @param int $id  - entity id to which the vtiger_files to be uploaded
	 *      @param string $module  - the current module name
	*/
	function insertIntoAttachment($id,$module){
		global $log, $adb;
		$log->debug("Entering into insertIntoAttachment($id,$module) method.");

		$file_saved = false;
		if(count($_FILES)) {
			foreach($_FILES as $fileindex => $files){
				if($files['name'] != '' && $files['size'] > 0){
					$filename = $files['name'];
					$files['original_name'] = vtlib_purify($_REQUEST[$fileindex.'_hidden']);
					$file_saved = $this->uploadAndSaveFile($id,$module,$files);
				}
			}
		}
		if($filename){
			$query = "UPDATE vtiger_ctwhatsappbusinesstemplates SET wptemplate_image = ? WHERE ctwhatsappbusinesstemplatesid = ?";
			$re=$adb->pquery($query,array(decode_html($filename), $this->id));
		}

		$log->debug("Exiting from insertIntoAttachment($id,$module) method.");
	}
}