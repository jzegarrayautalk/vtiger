<?php
/*+**********************************************************************************
 * The content of this file is subject to the CRMTiger Pro license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is vTiger
 * The Modified Code of the Original Code owned by https://crmtiger.com/
 * Portions created by CRMTiger.com are Copyright(C) CRMTiger.com
 * All Rights Reserved.
 ************************************************************************************/

class WhatsAppBusinessTemplates_WhatsAppTemplatesData_View extends Vtiger_IndexAjax_View {

	function __construct() {
		$this->exposeMethod('getModuleFields');
		$this->exposeMethod('getWhatsappTemplates');
		$this->exposeMethod('getWhatsappTemplateInWorkflow');
        $this->exposeMethod('syncWhatsAppTemplates');
        $this->exposeMethod('saveWhatsAppBusinessConfiguration');
        $this->exposeMethod('getWhatsAppTemplateButton');
        $this->exposeMethod('updateWhatsAppTemplateStatus');
	}

	function getModuleFields(Vtiger_Request $request) { 
		global $adb;
		$moduleName = $request->getModule();
		$modulesFields = WhatsAppBusinessTemplates_WhatsAppTemplatesData_View::getAllModuleEmailTemplateFields($request);
		$modulesFieldshtml = '<option value="">'.vtranslate('LBL_SELECT_OPTION','Vtiger').'</option>';
		foreach ($modulesFields as $key => $value) {
			$modulesFieldshtml .= '<option value='.$value[1].'>'.$value[0].'</option>';
		}
		$fieldData = array('modulesFieldshtml' => $modulesFieldshtml);
		
		$response = new Vtiger_Response();
		$response->setResult($fieldData);
		$response->emit();
	}

	function getWhatsappTemplateInWorkflow(Vtiger_Request $request){
		$moduleName = $request->get('moduleName');
		$templatesArray = WhatsAppBusinessTemplates_Record_Model::getWhatsappTemplates($moduleName);
		$workflowEhatsappTemplate = '<option value="">'.vtranslate('LBL_SELECT_OPTION','Vtiger').'</option>';
		foreach ($templatesArray as $key => $value) {
			$workflowEhatsappTemplate .= '<option value='.$key.'>'.$value.'</option>';
		}
		$response = new Vtiger_Response();
		$response->setResult($workflowEhatsappTemplate);
		$response->emit();
	}

    public function getAllModuleEmailTemplateFields($request) {
    	$sourceModuleName = $request->get('sourcemodulename');
        $currentUserModel = Users_Record_Model::getCurrentUserModel();
        $allRelFields = array();
        
        $fieldList = $this->getRelatedFields($sourceModuleName, $currentUserModel);
        
        $allFields = array();
        foreach ($fieldList as $key => $field) {
            $option = array(vtranslate($field['module'], $field['module']) . ':' . vtranslate($field['fieldlabel'], $field['module']), "$" . strtolower($field['module']) . "-" . $field['columnname'] . "$");
            $allFields[] = $option;
            if (!empty($field['referencelist'])) {
                foreach ($field['referencelist'] as $referenceList) {
                    foreach($referenceList as $key => $relField) {
                    $relOption = array(vtranslate($field['fieldlabel'], $field['module']) . ':' . '(' . vtranslate($relField['module'], $relField['module']) . ')' . vtranslate($relField['fieldlabel'],$relField['module']), strtolower($field['module']) . "-" . $field['columnname'] . ":" . $relField['columnname']);
                    $allRelFields[] = $relOption;
                }
            }
        }
        }
        if(is_array($allFields) && is_array($allRelFields)){
            $allFields = array_merge($allFields, $allRelFields);
            $allRelFields= array();
        }
        return $allFields;
    }

    function getRelatedFields($module, $currentUserModel) {
        $handler = vtws_getModuleHandlerFromName($module, $currentUserModel);
        $meta = $handler->getMeta();
        $moduleFields = $meta->getModuleFields();
        $db = PearDatabase::getInstance();
        //adding record id merge tag option 
        $fieldInfo = array('columnname' => 'id','fieldname' => 'id','fieldlabel' =>vtranslate('LBL_RECORD_ID', $module));
        $recordIdField = WebserviceField::fromArray($db, $fieldInfo);
        $moduleFields[$recordIdField->getFieldName()] = $recordIdField;

        $returnData = array();
        foreach ($moduleFields as $key => $field) {
            if(!in_array($field->getPresence(), array(0,2))){
                continue;
            }
            $referencelist = array();
            $relatedField = $field->getReferenceList();
            if ($field->getFieldName() == 'assigned_user_id') {
                $relModule = 'Users';
                $referencelist[] = $this->getRelatedModuleFieldList($relModule, $currentUserModel);
            }
            if (!empty($relatedField)) {
                foreach ($relatedField as $ind => $relModule) {
                    $referencelist[] = $this->getRelatedModuleFieldList($relModule, $currentUserModel);
                }
            }
            $returnData[] = array('module' => $module, 'fieldname' => $field->getFieldName(), 'columnname' => $field->getColumnName(), 'fieldlabel' => $field->getFieldLabelKey(), 'referencelist' => $referencelist);
        }
        return $returnData;
    }

    function getRelatedModuleFieldList($relModule, $user) {
        $handler = vtws_getModuleHandlerFromName($relModule, $user);
        $relMeta = $handler->getMeta();
        if (!$relMeta->isModuleEntity()) {
            return array();
        }
        $relModuleFields = $relMeta->getModuleFields();
        $relModuleFieldList = array();
        foreach ($relModuleFields as $relind => $relModuleField) {
            if(!in_array($relModuleField->getPresence(), array(0,2))){
                continue;
            }
            if($relModule == 'Users') {
                if(in_array($relModuleField->getFieldDataType(),array('string','phone','email','text'))) {
                    $skipFields = array(98,115,116,31,32);
                    if(!in_array($relModuleField->getUIType(), $skipFields) && $relModuleField->getFieldName() != 'asterisk_extension'){
                        $relModuleFieldList[] = array('module' => $relModule, 'fieldname' => $relModuleField->getFieldName(), 'columnname' => $relModuleField->getColumnName(), 'fieldlabel' => $relModuleField->getFieldLabelKey());
                    }
                }
            } else {
                $relModuleFieldList[] = array('module' => $relModule, 'fieldname' => $relModuleField->getFieldName(), 'columnname' => $relModuleField->getColumnName(), 'fieldlabel' => $relModuleField->getFieldLabelKey());
            }
        }
        return $relModuleFieldList;
    }

    public function syncWhatsAppTemplates(Vtiger_Request $request) { 
        global $adb, $current_user;
        $moduleName = $request->getModule();
        $currentUserId = $current_user->id;

        $configurationData = Settings_CTWhatsAppBusiness_Record_Model::getUserConfigurationAllDataWithId($currentUserId);
        $api_url = $configurationData['api_url'];
        $authtoken = $configurationData['authtoken'];
        $whatsappAppid = $configurationData['whatsappAppid'];
        $whatsappAccountid = $configurationData['whatsappAccountid'];

        $curlURL = $api_url.$whatsappAccountid."/message_templates?access_token=".$authtoken;

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $curlURL,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_SSL_VERIFYPEER => 0,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_USERAGENT=>'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.13) Gecko/20080311 Firefox/2.0.0.13',
        ));

        $response = curl_exec($curl);
        $resultResponse = json_decode($response,true);
        curl_close($curl);

        foreach ($resultResponse['data'] as $key => $value) {
            $whatsAppTemplateId = $value['id'];
            $templateName = $value['name'];
            $language = $value['language'];
            $category = $value['category'];
            $status = $value['status'];

            $bodyText = $footerText = $headerType = $headerText = $headerVariableValue = $buttonsData = $mediaType = $headerMediaPath = '';
            $components = $value['components'];
            $bodyVariableValList = array();
            foreach($value['components'] as $cKey => $cValue){
                if($cValue['type'] == 'HEADER'){
                    if($cValue['format'] == 'TEXT'){
                        $headerType = "TEXT";
                        $headerText = $cValue['text'];
                        if(isset($cValue['example'])){
                            $headerVariableValue = $cValue['example']['header_text'][0];
                        }//end of if
                    }else{
                        $headerType = "MEDIA";
                        $mediaType = $cValue['format'];
                        $headerMediaPath = $cValue['example']['header_handle'];
                    }
                }else if($cValue['type'] == 'BODY'){
                    $bodyText = $cValue['text'];
                    if(isset($cValue['example'])){
                        if(isset($cValue['example']['body_text'])){
                            $i = 1;
                            foreach($cValue['example']['body_text'][0] as $bKey => $bValue){
                                $bodyVariableValList['{{'.$i.'}}'] = $bValue;
                                $i++;
                            }//end of foreach
                        }//end of if
                    }//end of if
                }else if($cValue['type'] == 'BUTTONS'){
                    $buttonsData = $cValue['buttons'];
                }else if($cValue['type'] == 'FOOTER'){
                    $footerText = $cValue['text'];
                }//end of else if
            }//end of foreach

            $bodyVariableContent = json_encode($bodyVariableValList);
           
            $templateExistQuery = $adb->pquery("SELECT * FROM vtiger_ctwhatsappbusinesstemplates 
                    INNER JOIN vtiger_crmentity ON vtiger_crmentity.crmid = vtiger_ctwhatsappbusinesstemplates.ctwhatsappbusinesstemplatesid 
                    WHERE vtiger_crmentity.deleted = 0 AND vtiger_ctwhatsappbusinesstemplates.whatsapp_business_template_id = ?", array($whatsAppTemplateId));
            $templateExistRows = $adb->num_rows($templateExistQuery);
            if($templateExistRows == 0){
                $recordModel = Vtiger_Record_Model::getCleanInstance($moduleName);
                $recordModel->set('mode', '');
            }else{
                $ctwhatsapptemplatesid = $adb->query_result($templateExistQuery, 0, 'ctwhatsappbusinesstemplatesid');
                $recordModel = Vtiger_Record_Model::getInstanceById($ctwhatsapptemplatesid, $moduleName);
                $recordModel->set('mode', 'edit');
            }//end of else

            $recordModel->set('wptemplate_title', $templateName);
            $recordModel->set('wptemplate_language', $language);
            $recordModel->set('category', $category);
            $recordModel->set('header_type', $headerType);
            $recordModel->set('header_text', $headerText);
            $recordModel->set('header_variable_value', $headerVariableValue);
            if($headerType == 'MEDIA'){
                $recordModel->set('media_type', $mediaType);
                $recordModel->set('media_file_path', $headerMediaPath);
            }else{
                $recordModel->set('media_type', '');
                $recordModel->set('media_file_path', '');
            }//end of else

            $recordModel->set('body_content', json_encode($bodyText));
			$recordModel->set('wptemplate_text', json_encode($bodyText));
            $recordModel->set('body_variable_value', $bodyVariableContent);
            $recordModel->set('footer_text', $footerText);
            $recordModel->set('assigned_user_id', 1);
            $recordModel->set('whatsapp_template_type', 'WhatsApp Business Template');
            $recordModel->set('whatsapp_business_template_id', $whatsAppTemplateId);
            $recordModel->set('whatsapp_template_status', $status);
            $recordModel->set('button_content', json_encode($buttonsData));
			$recordModel->set('wptemplate_status', 1);
            $recordModel->save();

            /*if($value['status'] == 'APPROVED'){
                $templateExistQuery = $adb->pquery("SELECT * FROM vtiger_ctwhatsappbusinesstemplates 
                    INNER JOIN vtiger_crmentity ON vtiger_crmentity.crmid = vtiger_ctwhatsappbusinesstemplates.ctwhatsappbusinesstemplatesid 
                    WHERE vtiger_crmentity.deleted = 0 AND vtiger_ctwhatsappbusinesstemplates.wptemplate_title = ?", array($templateName));
                $templateExistRows = $adb->num_rows($templateExistQuery);
                if($templateExistRows == 0){
                    $recordModel = Vtiger_Record_Model::getCleanInstance($moduleName);
                    $recordModel->set('mode', '');
                    $recordModel->set('wptemplate_title', $templateName);
                    $recordModel->set('wptemplate_text', $templateBody);
                    $recordModel->set('wptemplate_status', 1);
                    $recordModel->set('wptemplate_language', $language);
                    $recordModel->save();
                }else{
                    $ctwhatsapptemplatesid = $adb->query_result($templateExistQuery, 0, 'ctwhatsappbusinesstemplatesid');
                    $recordModel = Vtiger_Record_Model::getInstanceById($ctwhatsapptemplatesid, $moduleName);
                    $recordModel->set('mode', 'edit');
                    $recordModel->set('id', $ctwhatsapptemplatesid);
                    $recordModel->set('wptemplate_title', $templateName);
                    $recordModel->set('wptemplate_text', $templateBody);
                    $recordModel->set('wptemplate_status', 1);
                    $recordModel->set('wptemplate_language', $language);
                    $recordModel->save();
                }
            }*/
        }

    }

    function saveWhatsAppBusinessConfiguration(Vtiger_Request $request){
        global $adb, $site_URL, $current_user, $root_directory;
        $configurationData = WhatsAppBusinessTemplates_WhatsAppTemplatesData_View::getWhatsAppAPIConfigurationData();
        $headerContent = $footerContent = "";
        $formData = $request->get('formData');
        $saveType = $request->get('saveType');
        $base64imagedata = $request->get('base64imagedata');
        parse_str($formData, $formRequestData);
        
        $headerText = $mediaType = $footerText = $headerMediaPath = $headerVariableValue = '';
        if(isset($formRequestData['headerText'])){
            $headerText = $formRequestData['headerText'];
        }//end of if

        if(isset($formRequestData['mediaType'])){
            $mediaType = $formRequestData['mediaType'][0];
        }//end of if

        if(isset($formRequestData['headerVariableValue'])){
            $headerVariableValue = $formRequestData['headerVariableValue'];
        }//end of if
        
        $cnt = 0;
        $buttonContent = $extraButtonContent = '';
        $buttonsData = array();
        $iconsPath = 'layouts/v7/modules/WhatsAppBusinessTemplates/resources/icons/';
        if(isset($formRequestData['customButtonCnt']) && $formRequestData['customButtonCnt'] != 0){
            for($btnCnt=1;$btnCnt<=$formRequestData['customButtonCnt'];$btnCnt++){
                if(isset($formRequestData['customButtonDeleted_'.$btnCnt]) && $formRequestData['customButtonDeleted_'.$btnCnt] != '1'){
                    if(isset($formRequestData['customButtonText_'.$btnCnt]) && $formRequestData['customButtonText_'.$btnCnt] != ''){
                        $buttonsData[] = array('type' => 'QUICK_REPLY', 'text' => $formRequestData['customButtonText_'.$btnCnt]);
                        if($cnt < 2){
                            $buttonContent .= '<span class="preview_button"><img src="'.$iconsPath.'forward.png"><a href="javascript: void(0);">'.$formRequestData['customButtonText_'.$btnCnt].'</a></span>';
                        }else{
                            if($btnCnt == $formRequestData['customButtonCnt']){
                                $extraButtonContent = '<span class="preview_button"><img src="'.$iconsPath.'forward.png"><a href="javascript: void(0);">'.$formRequestData['customButtonText_'.$btnCnt].'</a></span>';
                            }//end of if
                        }//end of else
                        $cnt++;
                    }//end of if
                }//end of if
            }//end of for
        }//end of if

        if(isset($formRequestData['vistWebsiteButtonCnt']) && $formRequestData['vistWebsiteButtonCnt'] != 0){
            for($btnCnt=1;$btnCnt<=$formRequestData['vistWebsiteButtonCnt'];$btnCnt++){
                if(isset($formRequestData['visitWebsiteDeleted_'.$btnCnt]) && $formRequestData['visitWebsiteDeleted_'.$btnCnt] != '1'){
                    if($formRequestData['visitWebisteButtonURLType_'.$btnCnt] == 'Static'){
                        $buttonsData[] = array('type' => 'URL', 'text' => $formRequestData['visitWebisteButtonText_'.$btnCnt], 'url' => $formRequestData['visitWebisteURL_'.$btnCnt]);
                    }else{
                        $buttonsData[] = array('type' => 'URL', 'text' => $formRequestData['visitWebisteButtonText_'.$btnCnt], 'url' => $formRequestData['visitWebisteURL_'.$btnCnt], 'example' => json_encode(array($formRequestData['visitWebsiteSampleURL_'.$btnCnt])));
                    }//end of else
                    if($cnt < 2){
                        $buttonContent .= '<span class="preview_button"><img src="'.$iconsPath.'website.png"><a href="javascript: void(0);">'.$formRequestData['visitWebisteButtonText_'.$btnCnt].'</a></span>';
                    }else{
                        if($btnCnt == $formRequestData['vistWebsiteButtonCnt']){
                            $extraButtonContent = '<span class="preview_button"><img src="'.$iconsPath.'website.png"><a href="javascript: void(0);">'.$formRequestData['visitWebisteButtonText_'.$btnCnt].'</a></span>';
                        }//end of if
                    }//end of else
                    $cnt++;
                }//end of if
            }//end of for
        }//end of if

        if(isset($formRequestData['copyOfferCodeButtonCnt']) && $formRequestData['copyOfferCodeButtonCnt'] != 0){
            for($btnCnt=1;$btnCnt<=$formRequestData['copyOfferCodeButtonCnt'];$btnCnt++){
                if(isset($formRequestData['copyOfferCodeDeleted_'.$btnCnt]) && $formRequestData['copyOfferCodeDeleted_'.$btnCnt] != '1'){
                    $buttonsData[] = array('type' => 'COPY_CODE', 'example' => $formRequestData['offerCodeText_'.$btnCnt]);
                    
                    if($cnt < 2){
                        $buttonContent .= '<span class="preview_button"><img src="'.$iconsPath.'copy.png"><a href="javascript: void(0);">'.$formRequestData['offerCodeText_'.$btnCnt].'</a></span>';
                    }else{
                        if($btnCnt == $formRequestData['copyOfferCodeButtonCnt']){
                            $extraButtonContent = '<span class="preview_button"><img src="'.$iconsPath.'copy.png"><a href="javascript: void(0);">'.$formRequestData['offerCodeText_'.$btnCnt].'</a></span>';
                        }//end of if
                    }//end of else
                    $cnt++;
                }//end of if
            }//end of for
        }//end of if

        if(isset($formRequestData['callPhoneNumberButtonCnt']) && $formRequestData['callPhoneNumberButtonCnt'] != 0){
            for($btnCnt=1;$btnCnt<=$formRequestData['callPhoneNumberButtonCnt'];$btnCnt++){
                if(isset($formRequestData['callPhoneNumberDeleted_'.$btnCnt]) && $formRequestData['callPhoneNumberDeleted_'.$btnCnt] != '1'){
                    $buttonsData[] = array('type' => 'PHONE_NUMBER','text' => $formRequestData['callPhoneNumberButtonText_'.$btnCnt] , 'phone_number' => $formRequestData['phoneNumber_'.$btnCnt]);
                    
                    if($cnt < 2){
                        $buttonContent .= '<span class="preview_button"><img src="'.$iconsPath.'phone.png"><a href="javascript: void(0);">'.$formRequestData['callPhoneNumberButtonText_'.$btnCnt].'</a></span>';
                    }else{
                        if($btnCnt == $formRequestData['callPhoneNumberButtonCnt']){
                            $extraButtonContent = '<span class="preview_button"><img src="'.$iconsPath.'phone.png"><a href="javascript: void(0);">'.$formRequestData['callPhoneNumberButtonText_'.$btnCnt].'</a></span>';
                        }//end of if
                    }//end of else
                    $cnt++;
                }//end of if
            }//end of for
        }//end of if

        if($cnt >= 4){
            $buttonContent .= '<span class="preview_button"><img src="'.$iconsPath.'list.png"><a href="javascript: void(0);">'.vtranslate('LBL_SEE_ALL_OPTIONS', 'WhatsAppBusinessTemplates').'</a></span>';
        }else{
            $buttonContent .= $extraButtonContent;
        }//end of else
        
        $bodyVariableRowVal = $formRequestData['bodyVariableRowVal'];
        $bodyText = $formRequestData['bodyText'];
        $bodyContent = $formRequestData['bodyText'];
        $bodyVariableValList = $bodyVariableValArray = array();
        if($bodyVariableRowVal != 0){
            for($i=1;$i<=$bodyVariableRowVal;$i++){
                if(isset($formRequestData['bodyVariableVal_'.$i]) && $formRequestData['bodyVariableVal_'.$i] != ''){
                    $bodyVariableValList['{{'.$i.'}}'] = $formRequestData['bodyVariableVal_'.$i];
                    $bodyVariableValArray[] = $formRequestData['bodyVariableVal_'.$i];
                    $variableId = '{{'.$i.'}}';
                    $bodyContent = str_replace($variableId, $formRequestData['bodyVariableVal_'.$i], $bodyContent);
                }//end of if
            }//end of for
        }//end of if
        
        $bodyVariableContent = json_encode($bodyVariableValList);

        if(isset($formRequestData['footerText'])){
            $footerText = $formRequestData['footerText'];
        }//end of if
        
        if($base64imagedata != ''){
            header('Content-Type: text/html; charset=UTF-8');
            $fileName = rand().$request->get('fileName');
            
            $whatsappFolderPath = "/modules/WhatsAppBusinessTemplates/WhatsAppBusinessTemplatesStorage/";
            $year  = date('Y');
            $month = date('F');
            $day   = date('j');
            $week  = '';
            if (!is_dir($root_directory.$whatsappFolderPath)) {
                //create new folder
                mkdir($root_directory.$whatsappFolderPath);
                chmod($root_directory.$whatsappFolderPath, 0777);
            }//end of if

            if (!is_dir($root_directory.$whatsappFolderPath . $year)) {
                //create new folder
                mkdir($root_directory.$whatsappFolderPath . $year);
                chmod($root_directory.$whatsappFolderPath . $year, 0777);
            }//end of if

            if (!is_dir($root_directory.$whatsappFolderPath . $year . "/" . $month)) {
                //create new folder
                mkdir($root_directory.$whatsappFolderPath . "$year/$month/");
                chmod($root_directory.$whatsappFolderPath . "$year/$month/", 0777);
            }//end of if

            if ($day > 0 && $day <= 7)
                $week = 'week1';
            elseif ($day > 7 && $day <= 14)
                $week = 'week2';
            elseif ($day > 14 && $day <= 21)
                $week = 'week3';
            elseif ($day > 21 && $day <= 28)
                $week = 'week4';
            else
                $week = 'week5';  

            if (!is_dir($root_directory.$whatsappFolderPath . $year . "/" . $month . "/" . $week)) {
                //create new folder
                mkdir($root_directory.$whatsappFolderPath . "$year/$month/$week/");
                chmod($root_directory.$whatsappFolderPath . "$year/$month/$week/", 0777);
            }//end of if
            $targetFile = $root_directory.$whatsappFolderPath.$year.'/'.$month.'/'.$week.'/';

            list($type, $base64imagedata) = explode(';', $base64imagedata);
            list(, $base64imagedata)      = explode(',', $base64imagedata);
            $base64imagedata = base64_decode($base64imagedata);
            
            $filemove = file_put_contents(($targetFile.$fileName),$base64imagedata);
            $headerMediaPath = $site_URL.$whatsappFolderPath.$year.'/'.$month.'/'.$week.'/'.$fileName;
        }else{
            if(isset($formRequestData['headerMediaPath']) && $formRequestData['headerMediaPath'] != ''){
                $headerMediaPath = $formRequestData['headerMediaPath'];
                $fileInfo = WhatsAppBusinessTemplates_WhatsAppTemplatesData_View::getRemoteFileInfo($headerMediaPath);
                $formRequestData['headerMediaFileLength'] = $fileInfo['fileSize'];
                $formRequestData['headerMediaFileType'] = $fileInfo['mimeType'];
            }//end of if
        }//end of else
        $headerComponent = $bodyComponent = $footerComponent = array();
        if($formRequestData['headerType'] == 'TEXT'){
            if($headerText != ''){
                $headerComponent['type'] = 'HEADER';
                $headerComponent['format'] = 'TEXT';
                $headerComponent['text'] = $headerText;

                $headerTextVal = $headerText;

                if($headerVariableValue != ''){
                    $headerVariableData = json_encode(array($headerVariableValue));
                    $headerComponent['example'] = array('header_text' => $headerVariableValue);

                    $headerTextVal = str_replace("{{1}}", $headerVariableValue, $headerText);
                }//end of if
                $headerContent .= '<h5>'.$headerTextVal.'</h5>';
            }//end of if
        }else if($formRequestData['headerType'] == 'MEDIA'){
            if($mediaType != ''){
                if($headerMediaPath != '' && $saveType == 'saveWhatsAppBusiness'){
                    $fileLength = $formRequestData['headerMediaFileLength'];
                    $fileType = $formRequestData['headerMediaFileType'];
                    $uploadSessionIdResponse = WhatsAppBusinessTemplates_WhatsAppTemplatesData_View::createHeaderUploadMediaSession($fileType, $fileLength, $configurationData);
                    
                    $sessionUploadData = json_decode($uploadSessionIdResponse);
                    
                    $headerHandle = '';
                    if(isset($sessionUploadData->id)){
                        $apiURL = $configurationData['api_url'];
                        $sessionUploadId = $sessionUploadData->id;
                        $intiateUploadURL = $apiURL.$sessionUploadId;
                        
                        $ch = curl_init();

                        curl_setopt($ch, CURLOPT_URL, $intiateUploadURL);
                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                        curl_setopt($ch, CURLOPT_POST, 1);
                        /*$post = array(
                            'file' => new CURLFile($headerMediaPath)
                        );*/
                        $post = file_get_contents($headerMediaPath);
                        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);

                        $headers = array();
                        $headers[] = 'Authorization: OAuth '.$configurationData['authtoken'];
                        $headers[] = 'File_offset: 0';
                        $headers[] = 'Content-Type: application/x-www-form-urlencoded';
                        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

                        $result = curl_exec($ch);
                        
                        curl_close($ch);
                        
                        if(isset($result->error)){
                            $errorMessage = $result->error;
                            $templateDataVal = array('errorMessage' => $errorMessage);
                            $response = new Vtiger_Response();
                            $response->setResult($templateDataVal);
                            $response->emit();
                            exit;
                        }else{
                            $handlerResponseData = json_decode($result);
                            $headerHandle = json_encode(array($handlerResponseData->h));
                        }//end of else
                    }else{
                        if(isset($sessionUploadData->error)){
                            $errorMessage = $sessionUploadData->error;
                            $templateDataVal = array('errorMessage' => $errorMessage);
                            $response = new Vtiger_Response();
                            $response->setResult($templateDataVal);
                            $response->emit();
                            exit;
                        }//end of if
                    }//end of else

                    if($headerHandle != ''){
                        $headerComponent['type'] = 'HEADER';
                        $headerComponent['format'] = $mediaType;
                        $headerComponent['example'] = array('header_handle' => $headerHandle);
                    }//end of if
                }//end of if

                if($mediaType == 'IMAGE'){
                    $headerContent .= '<img src="'.$headerMediaPath.'"/>';
                }else if($mediaType == 'VIDEO'){
                    $headerContent .= '<video width="100%" controls><source src="'.$headerMediaPath.'" type="'.$fileType.'"></video>';
                }else if($mediaType == 'DOCUMENT'){
                    $headerContent .= '<iframe src="'.$headerMediaPath.'#toolbar=0" width="100%" height="300"></iframe>';
                }//end of else if
            }//end of if
        }//end of else if
        
        $bodyTextVal = json_encode($bodyVariableValArray);
        $bodyComponent['type'] = 'BODY';
        $bodyComponent['text'] = $formRequestData['bodyText'];
        
        if(!empty($bodyVariableValArray)){
            $bodyComponent['example'] = array('body_text' => array($bodyTextVal));
        }//end of if 

        $comonentsArray = array();
        if(!empty($headerComponent)){
            $comonentsArray[] = $headerComponent;     
        }//end of if

        $comonentsArray[] = $bodyComponent;
        
        if($footerText != ''){
            $footerComponent['type'] = 'FOOTER';
            $footerComponent['text'] = $footerText;

            $comonentsArray[] = $footerComponent;

            $footerContent = $footerText; 
        }//end of if

        if(!empty($buttonsData)){
            $buttonComonent = array();
            $buttonComonent['type'] = 'BUTTONS';
            $buttonComonent['buttons'] = json_encode($buttonsData);

            $comonentsArray[] = $buttonComonent;
        }//end of if
        
        if($formRequestData['whatsAppBusinessTemplateId'] != ''){
             $postFields = array(
                        'category' => $formRequestData['templateCategory'],
                        'components' => json_encode($comonentsArray)
                    );
        }else{
            $postFields = array(
                        'name' => $formRequestData['templateName'],
                        'category' => $formRequestData['templateCategory'],
                        'language' => $formRequestData['templateLanguage'],
                        'components' => json_encode($comonentsArray)
                    );
        }//end of else

        
        $templateResponse = '';
        if($saveType == 'saveWhatsAppBusiness'){
            $templateResponse = WhatsAppBusinessTemplates_WhatsAppTemplatesData_View::createWhatsAppBusinessTemplate($postFields, $configurationData, $formRequestData['whatsAppBusinessTemplateId']);
        }//end of if
        if(isset($templateResponse->error)){
            $errorMessage = $templateResponse->error;
            $templateDataVal = array('errorMessage' => $errorMessage);
            $response = new Vtiger_Response();
            $response->setResult($templateDataVal);
            $response->emit();
            exit;
        }else{
            if($formRequestData['recordId'] == ''){
                $recordModel = Vtiger_Record_Model::getCleanInstance('WhatsAppBusinessTemplates');
                $recordModel->set('mode', '');
                $recordModel->set('wptemplate_title', $formRequestData['templateName']);
                $recordModel->set('wptemplate_language', $formRequestData['templateLanguage']);
            }else{
                $recordModel = Vtiger_Record_Model::getInstanceById($formRequestData['recordId'], 'WhatsAppBusinessTemplates');
                $recordModel->set('mode', 'edit');
                if($recordModel->get('whatsapp_business_template_id') == ''){
                    $recordModel->set('wptemplate_title', $formRequestData['templateName']);
                    $recordModel->set('wptemplate_language', $formRequestData['templateLanguage']);
                }//end of if
            }//end of else
            
            $recordModel->set('category', $formRequestData['templateCategory']);
            $recordModel->set('header_type', $formRequestData['headerType']);
            $recordModel->set('header_text', $headerText);
            $recordModel->set('header_variable_value', $headerVariableValue);
            if($formRequestData['headerType'] == 'MEDIA'){
                $recordModel->set('media_type', $mediaType);
                $recordModel->set('media_file_path', $headerMediaPath);
            }else{
                $recordModel->set('media_type', '');
                $recordModel->set('media_file_path', '');
            }//end of else
            $recordModel->set('body_content', json_encode($bodyText));
            $recordModel->set('body_variable_value', $bodyVariableContent);
            $recordModel->set('footer_text', $footerText);
            $recordModel->set('assigned_user_id', 1);
            $recordModel->set('whatsapp_template_type', 'WhatsApp Business Template');
            if($saveType != 'savePreview'){
                $recordModel->set('whatsapp_business_template_id', $templateResponse->id);
                $recordModel->set('whatsapp_template_status', $templateResponse->status);
            }//end of if
            $recordModel->set('button_content', json_encode($buttonsData));
            $recordModel->save();

            if($saveType == 'savePreview'){
                global $adb;
                $moduleName = $request->getModule();
                $viewer = $this->getViewer($request);
                $viewer->assign("HEADER", $headerContent);
                $bodyHtml = htmlspecialchars($bodyContent);
                $viewer->assign("BODY", $bodyHtml);
                $viewer->assign("BUTTONDATA", $buttonContent);
                $viewer->assign("FOOTER", $footerContent);
                $viewer->assign('MODULE',$moduleName);

                $userTime = DateTimeField::convertToUserTimeZone($time);
                $getUserTime = $userTime->format('h:i A');
                
                $viewer->assign('PREVIEW_TIME',$getUserTime);
                if($errorMessage){
                    $templateDataVal = array('errorMessage' => $errorMessage);
                    $response = new Vtiger_Response();
                    $response->setResult($templateDataVal);
                    $response->emit();
                    exit;
                }else{
                    $previewData = $viewer->view('whatsAppBusinessTemplatePreview.tpl', $moduleName, true);
                    $recordData = $recordModel->getId();
                    $templateDataVal = array('errorMessage' => '', 'previewHtml' => $previewData, 'recordId' => $recordData);
                    $response = new Vtiger_Response();
                    $response->setResult($templateDataVal);
                    $response->emit();
                    exit;
                }//end of else
                exit;
            }//end of if
        }//end of else
        
        if($errorMessage != ''){
            $errorMessage = $templateResponse->error;
            $templateDataVal = array('errorMessage' => $errorMessage);
            $response = new Vtiger_Response();
            $response->setResult($templateDataVal);
            $response->emit();
            exit;
        }//end of if      
    }//end of function

    public function getWhatsAppAPIConfigurationData(){
        global $adb, $current_user;
        $currentUserId = $current_user->id;
        
        $configurationData = Settings_CTWhatsAppBusiness_Record_Model::getUserConfigurationAllDataWithId($currentUserId);

        return $configurationData;
    }//end of function

    public function createWhatsAppBusinessTemplate($postFields, $configurationData, $templateId){
        $apiURL = $configurationData['api_url'];
        $authtoken = $configurationData['authtoken'];
        $whatsappAccountId = $configurationData['whatsappAccountid'];

        $headers = array(
            'Authorization: Bearer '.$authtoken,
            'Content-Type: application/json'
          );
        
        if($templateId != ''){
            $curlURL = $apiURL.'/'.$templateId;
        }else{
            $curlURL = $apiURL.$whatsappAccountId."/message_templates";
        }//end of else
    
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $curlURL,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => json_encode($postFields),
            CURLOPT_HTTPHEADER => $headers
        ));

        $response = curl_exec($curl);
        curl_close($curl);

        $createTemplateResponse = json_decode($response);

        return $createTemplateResponse;
    }//end of function

    public function createHeaderUploadMediaSession($fileType, $fileLength, $configurationData){
        $apiURL = $configurationData['api_url'];
        $authtoken = $configurationData['authtoken'];
        $whatsappAppId = $configurationData['whatsappAppid'];
        $whatsappAccountId = $configurationData['whatsappAccountid'];

        $curlURL = $apiURL.'/'.$whatsappAppId."/uploads?file_length=".$fileLength."&file_type=".$fileType."&access_token=".$authtoken;

        $headers = array(
            'Content-Type: application/json'
        );
        $postData = array();
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $curlURL,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => json_encode($postData),
            CURLOPT_HTTPHEADER => $headers
        ));

        $response = curl_exec($curl);
        curl_close($curl);

        return $response;
    }//end of function

    public function getRemoteFileInfo($url) {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HEADER, TRUE);
        curl_setopt($ch, CURLOPT_NOBODY, TRUE);
        
        $data = curl_exec($ch);
        $content_info = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
        $content_parts = explode(";", $content_info);
        $mime = $content_parts[0];
        $fileSize = curl_getinfo($ch, CURLINFO_CONTENT_LENGTH_DOWNLOAD);
        $httpResponseCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return [
            'fileExists' => (int) $httpResponseCode == 200,
            'fileSize' => (int) $fileSize,
            'mimeType' => $mime
        ];
    }//end of function

    function getWhatsAppTemplateButton(Vtiger_Request $request){
        $buttonType = $request->get('buttonTypeVal');
        $buttonCnt = $request->get('buttonCnt');
        $actionButton = $request->get('actionButton');
        $module = $request->get('module');
        
        $html = '';
        if($buttonType == 'quick_replay_button'){
            $buttonData = $request->get('buttonData');
            if($buttonCnt == 1){
                $html .= '<div class="dynamicButtonBox">
                            <h4>'.vtranslate('LBL_QUICK_REPLAY', $module).'</h4>';
            }//end of if

            $buttonTextLabel = vtranslate('LBL_BUTTON_TEXT', $module);
            $customButtonId = 'customButtonText_'.$buttonCnt;
            $textCnt = strlen($buttonData);
            $html .= '<div class="dynamicButtonBoxData" id="dynamicButtonBox'.$buttonCnt.'">
                             <input type="hidden" name="customButtonDeleted_'.$buttonCnt.'" id="customButtonDeleted_'.$buttonCnt.'" value="0">
                            <h5>'.$buttonTextLabel.'</h5>
                            <span class="mainspan">
                                <span class="textBoxCharacterSpan">'.$textCnt.'/25</span>
                                <input type="text" class="inputElement customButtonText inputErrorClass" name="'.$customButtonId.'" id="'.$customButtonId.'" maxlength="25" value="'.$buttonData.'">
                                <span class="deleteConditionSpan" data-cnt="'.$buttonCnt.'">
                                    <i class="deleteCondition glyphicon glyphicon-trash cursorPointer" title="'.vtranslate('LBL_DELETE', $module).'"></i>
                                </span>
                            </span>
                        </div>';

            if($buttonCnt == 1){
                $html .= '<div class="addButtonDiv" style="text-align: right;">
                            <button type="button" name="addButton" id="addButton" class="addButton btn btn-success" data-id="quick_replay_button">'.vtranslate('LBL_ADD_BUTTON', $module).'</button>
                        </div>';
                $html .= '</div>';
            }//end of if
        }else if($buttonType == 'Visit Website'){
            $buttonData = $request->get('buttonData');
            $buttonText = $buttonURL = $sampleURL = $selectedDynamic = $selectedStatic = '';
            $urlType = 'Static';
            if($buttonData != ''){
                $buttonText = $buttonData['text'];
                $buttonURL = $buttonData['url'];
                if(strpos($buttonURL,'{{1}}') !== false){
                    $urlType = 'Dynamic';
                    $selectedDynamic = 'selected';
                    $exampleData = json_decode($buttonData['example']);
                    $sampleURL = $exampleData[0];
                }else{
                    $selectedStatic = 'selected';
                }//end of else
            }//end of if
            if($actionButton == 0){
                $html .= '<div class="action-div">
                            <h4>'.vtranslate('LBL_CALL_TO_ACTIONS', $module).'</h4>';
            }//end of if

            $buttonTextCnt = strlen($buttonText);
            $buttonURLCnt = strlen($buttonURL);

            if($buttonCnt == 1){
                $html .= '<div class="white-wrap-div visitWebsiteDiv">';
            }else{
                $html .= '<br>';
            }
            $html .= '<div class="visitWebsiteInnerDiv"><input type="hidden" name="visitWebsiteDeleted_'.$buttonCnt.'" id="visitWebsiteDeleted_'.$buttonCnt.'" value="0">
                          <div class="inner-div" id="visitWebsiteRow_'.$buttonCnt.'">
                            <div class="inner-div-wrap">
                              ';
            $typeofActionLabel =vtranslate('LBL_TYPE_OF_ACTION', $module);
            $buttonTextLabel = vtranslate('LBL_BUTTON_TEXT', $module);
            $buttonTextId = 'visitWebisteButtonText_'.$buttonCnt;
            $urlTypeId = 'visitWebisteButtonURLType_'.$buttonCnt;
            $vistiWebsiteURLId = 'visitWebisteURL_'.$buttonCnt;

            $html .= '<div class="lable-wrapper">
                        <label for="">'.$typeofActionLabel.'</label><br>
                        <select class="inputElement" name="visitwebsite_action_'.$buttonCnt.'" id="visitwebsite_action_'.$buttonCnt.'">
                            <option value="Visit Website">'.vtranslate('LBL_VISIT_WEBSITE', $module).'</option>
                        </select></div>';
            
            $html .= '<div class="lable-wrapper">
                    <label for="">'.$buttonTextLabel.'</label> <br>
                    <span class="mainspan">
                        <span class="textBoxCharacterSpan">'.$buttonTextCnt.'/25</span>
                        <input type="text" value="'.$buttonText.'" id="'.$buttonTextId.'" name="'.$buttonTextId.'" class="inputElement visitWebsiteButtonText inputErrorClass" maxlength="25">
                    </span>
                  </div>';

            $html .= '<div class="lable-wrapper">
            <label for="">'.vtranslate('LBL_URL_TYPE', $module).'</label> <br>
            <select name="'.$urlTypeId.'" id="'.$urlTypeId.'" class="inputElement urlType">
              <option value="Static" '.$selectedStatic.'>'.vtranslate('LBL_STATIC',$module).'</option>
              <option value="Dynamic" '.$selectedDynamic.'>'.vtranslate('LBL_DYNAMIC',$module).'</option>
            </select>
          </div>';
            
            $html .= '<div class="lable-wrapper">
            <label for="">'.vtranslate('LBL_WEBSITE_URL', $module).'</label> <br>
            <span class="mainspan">
                <span class="textBoxCharacterSpan">'.$buttonURLCnt.'/200</span>
                <input type="text" value="'.$buttonURL.'" name="'.$vistiWebsiteURLId.'" id="'.$vistiWebsiteURLId.'" class="inputElement visitWebsiteURL inputErrorClass" maxlength="200">
            </span>
          </div><div class="lable-wrapper"><label></label><br><span class="deleteConditionSpan" data-cnt="'.$buttonCnt.'">
                                    <i class="deleteConditionVisitWebsite glyphicon glyphicon-trash cursorPointer" title="'.vtranslate('LBL_DELETE', $module).'"></i>
                                </span></div>';
            $visitWebisteSampleURL = 'visitWebsiteSampleURL_'.$buttonCnt;
            $html .= '</div><br>
                    <p class="addSampleURL_'.$buttonCnt.'"><b>'.vtranslate('LBL_ADD_SAMPLE_URL', $module).'</b></p>
                    <p class="gray-color addSampleURL_'.$buttonCnt.'">'.vtranslate('LBL_ADD_SAMPLE_URL_DESCRIPTION', $module).'</p>
                    <label for="" class="mt-10 addSampleURL_'.$buttonCnt.'">'.vtranslate('LBL_HEADER_VARIABLE_1', $module).'</label> <br>
                    <input type="text" id="'.$visitWebisteSampleURL.'" name="'.$visitWebisteSampleURL.'" value="'.$sampleURL.'" placeholder="'.vtranslate('LBL_ENTER_FULL_URL', $module).'" class="w-100 inputElement inputErrorClass addSampleURL_'.$buttonCnt.'">
                    </div></div>';

            if($buttonCnt == 1){
                $html .= '<div class="addButtonDiv" style="text-align: right;margin-top:10px;">
                            <button type="button" name="addButton" id="addButton" class="addButton btn btn-success" data-id="Visit Website">'.vtranslate('LBL_ADD_BUTTON', $module).'</button>
                        </div></div>';
            }//end of if

            if($actionButton == 0){
                $html .= '</div>';
            }//end of if

            
        }else if($buttonType == 'Copy Offer Code'){
            $buttonData = $request->get('buttonData');
            if(is_array($buttonData)){
                $offerCodeVal = $buttonData[0];
            }else{
                $offerCodeVal = $buttonData;
            }//end of else

            $offerCodeCnt = strlen($offerCodeVal);
            if($actionButton == 0){
                $html .= '<div class="action-div">
                            <h4>'.vtranslate('LBL_CALL_TO_ACTIONS', $module).'</h4>';
            }//end of if

            $html .= ' <div class="white-wrap-div">
                        <input type="hidden" name="copyOfferCodeDeleted_'.$buttonCnt.'" id="copyOfferCodeDeleted_'.$buttonCnt.'" value="0">
                          <div class="inner-div" id="copyOfferCodeRow_'.$buttonCnt.'">
                            <div class="inner-div-wrap">';

            $typeofActionLabel =vtranslate('LBL_TYPE_OF_ACTION', $module);
            $buttonTextLabel = vtranslate('LBL_BUTTON_TEXT', $module);
            $buttonTextId = 'copyOfferCodeButtonText_'.$buttonCnt;
            $offerCodeId = 'offerCodeText_'.$buttonCnt;

            $html .= '<div class="lable-wrapper">
                        <label for="">'.$typeofActionLabel.'</label><br>
                        <select class="inputElement" name="copyoffercode_action_'.$buttonCnt.'" id="copyoffercode_action_'.$buttonCnt.'">
                            <option value="Copy Offer Code">'.vtranslate('LBL_COPY_OFFER_CODE', $module).'</option>
                        </select></div>';

            $html .= '<div class="lable-wrapper">
                    <label for="">'.$buttonTextLabel.'</label> <br>
                    <span class="mainspan">
                        <input type="text" value="'.vtranslate('LBL_COPY_OFFER_CODE', $module).'" id="'.$buttonTextId.'" name="'.$buttonTextId.'" class="inputElement" readonly="true">
                    </span>
                  </div><div class="lable-wrapper"><label></label><br><span class="deleteConditionSpan" data-cnt="'.$buttonCnt.'">
                                    <i class="deleteConditionCopyOfferCode glyphicon glyphicon-trash cursorPointer" title="'.vtranslate('LBL_DELETE', $module).'"></i>
                                </span></div>';

            $html .= '</div><br>
                    <p class="addSampleOfferCode_'.$buttonCnt.'"><b>'.vtranslate('LBL_ADD_SAMPLE_OFFER_CODE', $module).'</b></p>
                    <p class="gray-color addSampleOfferCode_'.$buttonCnt.'">'.vtranslate('LBL_ADD_SAMPLE_OFFER_CODE_DESCRIPTION', $module).'</p>
                    <label for="" class="mt-10 addSampleOfferCode_'.$buttonCnt.'">'.vtranslate('LBL_OFFER_CODE', $module).'</label> <br>
                    <span class="mainspan">
                        <span class="textBoxCharacterSpan">'.$offerCodeCnt.'/15</span>
                        <input type="text" id="'.$offerCodeId.'" name="'.$offerCodeId.'" value="'.$offerCodeVal.'" placeholder="'.vtranslate('LBL_ENTER_SAMPLE', $module).'" class="w-100 inputElement offerCode inputErrorClass addSampleOfferCode_'.$buttonCnt.'" maxlength=15>
                    </span>
                    </div></div>';

            if($actionButton == 0){
                $html .= '</div>';
            }//end of if
        }else if($buttonType == 'Call Phone Number'){
            $buttonData = $request->get('buttonData');
            $buttonText = $phoneNumber = '';
            if($buttonData != ''){
                $buttonText = $buttonData['text'];
                $phoneNumber = $buttonData['phone_number'];
            }//end of if
            $buttonTextCnt = strlen($buttonText);
            $phoneNumberCnt = strlen($phoneNumber);
            if($actionButton == 0){
                $html .= '<div class="action-div">
                            <h4>'.vtranslate('LBL_CALL_TO_ACTIONS', $module).'</h4>';
            }//end of if

            $html .= ' <div class="white-wrap-div">
                        <input type="hidden" name="callPhoneNumberDeleted_'.$buttonCnt.'" id="callPhoneNumberDeleted_'.$buttonCnt.'" value="0">
                          <div class="inner-div" id="callPhoneNumberRow_'.$buttonCnt.'">
                            <div class="inner-div-wrap">';

            $typeofActionLabel =vtranslate('LBL_TYPE_OF_ACTION', $module);
            $buttonTextLabel = vtranslate('LBL_BUTTON_TEXT', $module);
            $buttonTextId = 'callPhoneNumberButtonText_'.$buttonCnt;
            $phoneNumberId = 'phoneNumber_'.$buttonCnt;
            

            $html .= '<div class="lable-wrapper">
                        <label for="">'.$typeofActionLabel.'</label><br>
                        <select class="inputElement" name="callphonenumber_action_'.$buttonCnt.'" id="callphonenumber_action_'.$buttonCnt.'">
                            <option value="Call Phone Number">'.vtranslate('LBL_CALL_PHONE_NUMBER', $module).'</option>
                        </select></div>';

            $html .= '<div class="lable-wrapper">
                    <label for="">'.$buttonTextLabel.'</label> <br>
                    <span class="mainspan">
                        <span class="textBoxCharacterSpan">'.$buttonTextCnt.'/25</span>
                        <input type="text" value="'.$buttonText.'" id="'.$buttonTextId.'" name="'.$buttonTextId.'" class="inputElement customButtonText inputErrorClass" maxlength="25">
                    </span>
                  </div>';

            $html .= '<div class="lable-wrapper">
                    <label for="">'.vtranslate('LBL_PHONE_NUMBER', $module).'</label> <br>
                    <span class="mainspan">
                        <span class="textBoxCharacterSpan">'.$phoneNumberCnt.'/20</span>
                        <input type="text" value="'.$phoneNumber.'" id="'.$phoneNumberId.'" name="'.$phoneNumberId.'" class="inputElement phoneNumberVal inputErrorClass" maxlength="20">
                    </span>
                  </div><div class="lable-wrapper"><label></label><br><span class="deleteConditionSpan" data-cnt="'.$buttonCnt.'">
                                    <i class="deleteConditionCallPhoneNumber glyphicon glyphicon-trash cursorPointer" title="'.vtranslate('LBL_DELETE', $module).'"></i>
                                </span></div></div></div></div>';

            if($actionButton == 0){
                $html .= '</div>';
            }//end of if
        }//end of else if

        echo $html;
    }//end of function

    function updateWhatsAppTemplateStatus(Vtiger_Request $request){
        global $log;
        $module = $request->get('module');

        $templateDataList = WhatsAppBusinessTemplates_Record_Model::getWhatsAppBusinessTemplateId();
        
        $configurationData = WhatsAppBusinessTemplates_WhatsAppTemplatesData_View::getWhatsAppAPIConfigurationData();

        $apiURL = $configurationData['api_url'];
        $authtoken = $configurationData['authtoken'];
        $whatsappAccountId = $configurationData['whatsappAccountid'];

        $curlURL = $apiURL.'/'.$whatsappAccountId.'/message_templates?fields=status';

        $headers = array(
            'Authorization: Bearer '.$authtoken,
            'Content-Type: application/json'
        );

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $curlURL,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => $headers
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        $templateData = json_decode($response);
        
        if(isset($templateData->error)){
            echo json_encode($templateData->error);
        }else{
            foreach ($templateData as $key => $value) {
                foreach ($value as $templateKey => $templateDetails) {
                    if(in_array($templateDetails->id, $templateDataList)){
                        $recordId = array_search($templateDetails->id, $templateDataList);
                        $recordInstance = Vtiger_Record_Model::getInstanceById($recordId, $module);
                        $log->debug('recordId =>'.$recordId);
                        $log->debug('templateStatus =>'.$templateDetails->status);
                        $recordInstance->set('mode', 'edit');
                        $recordInstance->set('whatsapp_template_status', $templateDetails->status);
                        $recordInstance->save();
                    }//end of if
                }//end of foreach
            }//end of foreach
        }//end of else
    }//end of function
}
