<?php

/* +***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 * *********************************************************************************** */

class WhatsAppBusinessTemplates_WhatsAppTemplateWidget_View extends Vtiger_Edit_View {

	function checkPermission(Vtiger_Request $request) {
        return true;
    }//end of function

	public function process(Vtiger_Request $request) {
		global $adb, $current_user, $site_URL;

        $moduleName = $request->getModule();
        $viewer = $this->getViewer($request);
        $viewer->view('WhatsAppTemplateWidget.tpl', $moduleName);
	}//end of function

	public function getHeaderCss(Vtiger_Request $request) {
        $moduleName = $request->getModule();
        $parentCSSScripts = parent::getHeaderCss($request);
        $styleFileNames = array(
            "~/layouts/v7/modules/WhatsAppBusinessTemplates/resources/css/WhatsAppTemplateWidget.css",
        );
        
        $cssScriptInstances = $this->checkAndConvertCssStyles($styleFileNames);
        $headerCSSScriptInstances = array_merge($parentCSSScripts, $cssScriptInstances);
        return $headerCSSScriptInstances;
    }//end of function
}//end of class