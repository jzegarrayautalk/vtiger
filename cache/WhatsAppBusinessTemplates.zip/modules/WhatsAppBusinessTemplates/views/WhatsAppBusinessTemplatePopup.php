<?php

/* +***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 * *********************************************************************************** */
class WhatsAppBusinessTemplates_WhatsAppBusinessTemplatePopup_View extends Vtiger_Edit_View {

	public function process(Vtiger_Request $request) {
		global $adb,$current_user;

		$moduleName = $request->getModule();
		$recordId = $request->get('record');

		$viewer = $this->getViewer($request);

		$templateLanguage = '';
		if($recordId != ''){
			$recordModel = Vtiger_Record_Model::getInstanceById($recordId, $moduleName);
			$fileName = '';
			if($recordModel->get('media_file_path') != ''){
				$fileData = $recordModel->get('media_file_path');
				$fileDataVal = explode('/', $fileData);
				$fileName = end($fileDataVal);
			}//end of if
			
			$whatsAppTemplateData = array(
									'recordId' => $recordId,
									'templateName' => $recordModel->get('wptemplate_title'),
									'templateCategory' => $recordModel->get('category'),
									'headerType' => $recordModel->get('header_type'),
									'headerText' => $recordModel->get('header_text'),
									'headerVariableValue' => $recordModel->get('header_variable_value'),
									'mediaType' => $recordModel->get('media_type'),
									'headerMediaPath' => $recordModel->get('media_file_path'),
									'fileName' => $fileName,
									'bodyText' => json_decode(html_entity_decode($recordModel->get('body_content'))),
									'bodyVariableValue' => json_decode(html_entity_decode($recordModel->get('body_variable_value'))),
									'buttonsData' => json_decode(html_entity_decode($recordModel->get('button_content'))),
									'footerText' => $recordModel->get('footer_text'),
									'whatsAppBusinessTemplateId' => $recordModel->get('whatsapp_business_template_id'),
									'whatsAppTemplateStatus' => $recordModel->get('whatsapp_template_status'),
								);

			$headerContent = $bodyContent = $buttonContent = $extraButtonContent = '';
			if($recordModel->get('header_type') == 'TEXT'){
				$headerTextVal = $recordModel->get('header_text');
				if($headerTextVal != ''){
					$headerVariableValue = $recordModel->get('header_variable_value');
					if($headerVariableValue != ''){
	                    $headerTextVal = str_replace("{{1}}", $headerVariableValue, $headerTextVal);
	                }//end of if
	                $headerContent .= '<h5>'.$headerTextVal.'</h5>';
				}//end of if
			}else if($recordModel->get('header_type') == 'MEDIA'){
				$mediaType = $recordModel->get('media_type');
				$headerMediaPath = $recordModel->get('media_file_path');
				if($mediaType == 'IMAGE'){
                    $headerContent .= '<img src="'.$headerMediaPath.'"/>';
                }else if($mediaType == 'VIDEO'){
                    $headerContent .= '<video width="100%" controls><source src="'.$headerMediaPath.'" type="'.$fileType.'"></video>';
                }else if($mediaType == 'DOCUMENT'){
                    $headerContent .= '<iframe src="'.$headerMediaPath.'#toolbar=0" width="100%" height="300"></iframe>';
                }//end of else if
			}//end of else if

			$bodyContent = json_decode(html_entity_decode($recordModel->get('body_content')));
			$bodyVariableValue = json_decode(html_entity_decode($recordModel->get('body_variable_value')));
			foreach ($bodyVariableValue as $key => $value) {
				$bodyContent = str_replace($key, $value, $bodyContent);
			}//end of foreach

			$buttonData = json_decode(html_entity_decode($recordModel->get('button_content')));

			$iconsPath = 'layouts/v7/modules/WhatsAppBusinessTemplates/resources/icons/';
			$cnt = 0;
			$totalButtonCnt = count($buttonData);
			foreach($buttonData as $buttonKey => $buttonVal){
				if($buttonVal->type == 'QUICK_REPLY'){
					if($cnt < 2){
						$buttonContent .= '<span class="preview_button"><img src="'.$iconsPath.'forward.png"><a href="javascript: void(0);">'.$buttonVal->text.'</a></span>';
					}else{
						$extraButtonContent = '<span class="preview_button"><img src="'.$iconsPath.'forward.png"><a href="javascript: void(0);">'.$buttonVal->text.'</a></span>';
					}//end of else
					$cnt++;
                }else if($buttonVal->type == 'URL'){
                	if($cnt < 2){
						$buttonContent .= '<span class="preview_button"><img src="'.$iconsPath.'website.png"><a href="javascript: void(0);">'.$buttonVal->text.'</a></span>';
					}else{
						$extraButtonContent = '<span class="preview_button"><img src="'.$iconsPath.'website.png"><a href="javascript: void(0);">'.$buttonVal->text.'</a></span>';
					}//end of else
					$cnt++;
				}else if($buttonVal->type == 'PHONE_NUMBER'){
					if($cnt < 2){
						$buttonContent .= '<span class="preview_button"><img src="'.$iconsPath.'phone.png"><a href="javascript: void(0);">'.$buttonVal->text.'</a></span>';
					}else{
						$extraButtonContent = '<span class="preview_button"><img src="'.$iconsPath.'phone.png"><a href="javascript: void(0);">'.$buttonVal->text.'</a></span>';
					}//end of else
					$cnt++;
				}else if($buttonVal->type == 'COPY_CODE'){
					if(is_array($buttonVal->example)){
						$offcerCodeVal = $buttonVal->example[0];
					}else{
						$offcerCodeVal = $buttonVal->example;
					}
					if($cnt < 2){
						$buttonContent .= '<span class="preview_button"><img src="'.$iconsPath.'copy.png"><a href="javascript: void(0);">'.$offcerCodeVal.'</a></span>';
					}else{
						$extraButtonContent = '<span class="preview_button"><img src="'.$iconsPath.'copy.png"><a href="javascript: void(0);">'.$offcerCodeVal.'</a></span>';
					}//end of else
					$cnt++;
				}//end of else if
			}//end of foreach

			if($totalButtonCnt >= 4){
	            $buttonContent .= '<span class="preview_button"><img src="'.$iconsPath.'list.png"><a href="javascript: void(0);">'.vtranslate('LBL_SEE_ALL_OPTIONS', 'WhatsAppBusinessTemplates').'</a></span>';
	        }else{
	            $buttonContent .= $extraButtonContent;
	        }//end of else

			$footerContent = $recordModel->get('footer_text');

			$viewer = $this->getViewer($request);
            $viewer->assign("HEADER", $headerContent);
            $bodyHtml = htmlspecialchars($bodyContent);
            $viewer->assign("BODY", $bodyHtml);
            $viewer->assign("BUTTONDATA", $buttonContent);
            $viewer->assign("FOOTER", $footerContent);
            $viewer->assign('MODULE',$moduleName);

            $userTime = DateTimeField::convertToUserTimeZone($time);
            $getUserTime = $userTime->format('h:i A');
            
            $viewer->assign('PREVIEW_TIME',$getUserTime);

            $previewData = $viewer->view('whatsAppBusinessTemplatePreview.tpl', $moduleName, true);

			$templateLanguage = $recordModel->get('wptemplate_language');
			$viewer->assign('WHATSAPP_TEMPLATE_DATA', $whatsAppTemplateData);
			$viewer->assign("PREVIEW_CONTENT", $previewData);
		}//end of if

		if($templateLanguage == ''){
			$templateLanguage = 'en_US';
		}//end of if

		$languagesList = WhatsAppBusinessTemplates_Record_Model::getWhatsappTemplateLanguages($templateLanguage);

		$viewer->assign("MODULENAME", $moduleName);
		$viewer->assign("LANGUAGES_LIST", $languagesList);

		echo $viewer->view('whatsAppBusinessTemplatePopup.tpl', $moduleName, true);
	}//end of function

	public function getHeaderCss(Vtiger_Request $request) {
        $moduleName = $request->getModule();
        $parentCSSScripts = parent::getHeaderCss($request);
        $styleFileNames = array(
            "~/layouts/v7/modules/WhatsAppBusinessTemplates/resources/css/WhatsAppTemplateWidget.css",
        );
        
        $cssScriptInstances = $this->checkAndConvertCssStyles($styleFileNames);
        $headerCSSScriptInstances = array_merge($parentCSSScripts, $cssScriptInstances);
        return $headerCSSScriptInstances;
    }//end of function
}//end of class