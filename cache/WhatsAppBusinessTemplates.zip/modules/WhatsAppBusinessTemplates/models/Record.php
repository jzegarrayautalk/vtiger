<?php
/*+**********************************************************************************
 * The content of this file is subject to the CRMTiger Pro license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is vTiger
 * The Modified Code of the Original Code owned by https://crmtiger.com/
 * Portions created by CRMTiger.com are Copyright(C) CRMTiger.com
 * All Rights Reserved.
 ************************************************************************************/
class WhatsAppBusinessTemplates_Record_Model extends Vtiger_Record_Model {
	
	/**
	 * Function to get Image Details
	 * @return <array> Image Details List
	 */
	public function getImageDetails($recordId) {
		$db = PearDatabase::getInstance();
		$imageDetails = array();
		if ($recordId) {
			$sql = "SELECT vtiger_attachments.*, vtiger_crmentity.setype FROM vtiger_attachments
						INNER JOIN vtiger_seattachmentsrel ON vtiger_seattachmentsrel.attachmentsid = vtiger_attachments.attachmentsid
						INNER JOIN vtiger_crmentity ON vtiger_crmentity.crmid = vtiger_attachments.attachmentsid
						WHERE vtiger_seattachmentsrel.crmid = ?";

			$result = $db->pquery($sql, array($recordId));

			$imageId = $db->query_result($result, 0, 'attachmentsid');
			$imagePath = $db->query_result($result, 0, 'path');
			$imageName = $db->query_result($result, 0, 'name');

			//decode_html - added to handle UTF-8 characters in file names
			$imageOriginalName = urlencode(decode_html($imageName));

			if(!empty($imageName)){
				$imageDetails[] = array(
						'id' => $imageId,
						'orgname' => $imageOriginalName,
						'path' => $imagePath.$imageId,
						'name' => $imageName
				);
			}
		}
		return $imageDetails;
	}

	public function getModulefields($request){
		global $adb;
		$sourceModuleName = $request->get('sourcemodulename');
		$tabid = getTabid($sourceModuleName);
		
		$getModuleFields = $adb->pquery("SELECT * FROM vtiger_field WHERE tabid = ?", array($tabid));
		$rows = $adb->num_rows($getModuleFields);
		$modulesFieldshtml = '<option value="">'.vtranslate('LBL_SELECT_OPTION','Vtiger').'</option>';
		for ($i=0; $i < $rows; $i++) { 
			$fieldName = $adb->query_result($getModuleFields, $i, 'columnname');
			$fieldLabel = $adb->query_result($getModuleFields, $i, 'fieldlabel');
			if($fieldName != 'source' && $fieldName != 'starred' && $fieldName != 'tags'){
				$modulesFieldshtml .= '<option value='.strtolower($sourceModuleName).'-'.$fieldName.'>'.vtranslate($fieldLabel,$fieldLabel).'</option>';
			}
		}

		return $modulesFieldshtml;
	}

	function getWhatsappTemplates($source_module){
		global $adb;
		$getWhatsappTemplateQuery = $adb->pquery("SELECT * FROM vtiger_ctwhatsappbusinesstemplates INNER JOIN vtiger_crmentity ON vtiger_crmentity.crmid = vtiger_ctwhatsappbusinesstemplates.ctwhatsappbusinesstemplatesid WHERE vtiger_crmentity.deleted = 0", array());
		$whatsappTemplateRows = $adb->num_rows($getWhatsappTemplateQuery);
		$templatesArray = array();
		for ($j=0; $j < $whatsappTemplateRows; $j++) { 
			$templatesID = $adb->query_result($getWhatsappTemplateQuery, $j, 'ctwhatsappbusinesstemplatesid');
			$templateTitle = $adb->query_result($getWhatsappTemplateQuery, $j, 'wptemplate_title');
			$templatesArray[$templatesID] = $templateTitle;
		}
		return $templatesArray;
	}

	public function getWhatsappAllowAllModules(){
		global $adb;
		$whatsappModuleQuery = $adb->pquery("SELECT * FROM vtiger_ctwharsappallow_whatsappmodule WHERE active = 1");
		$rows = $adb->num_rows($whatsappModuleQuery);
		
		$whatsaappModule = array();
		for ($i=0; $i < $rows; $i++) { 
			$module = $adb->query_result($whatsappModuleQuery, $i, 'module');
			$data = CTWhatsApp_Record_Model::checkPermissionModule($module);
			if($data == 1){
				$moduleIsEnable = CTWhatsApp_Record_Model::getmoduleIsEnable($module);

				if($moduleIsEnable == 0){
					$whatsaappModuleData = CTWhatsApp_Record_Model::getWhatsappAllowModuleFields($module);
					$phoneField = $whatsaappModuleData['phoneField'];
					$serach = '';
					$whatsaappModule[] = array('module' => $module, 'phoneField' => $phoneField);
				}
			}
		}
		return $whatsaappModule;
	}

	public function getWhatsappTemplateLanguages($templateLanguage){
		global $adb;
		$whatsappTemplateLanguageQuery = $adb->pquery("SELECT * FROM ctwhatsapp_template_languages");
		$rows = $adb->num_rows($whatsappTemplateLanguageQuery);
		
		$languagesListHtml = '<option value="">'.vtranslate('LBL_SELECT_OPTION','Vtiger').'</option>';
		for ($i=0; $i < $rows; $i++) { 
			$languageCode = $adb->query_result($whatsappTemplateLanguageQuery, $i, 'language_code');
			$languageName = $adb->query_result($whatsappTemplateLanguageQuery, $i, 'language_name');
			
			if($templateLanguage == $languageCode){
				$languagesListHtml .= '<option value='.$languageCode.' selected>'.$languageName.'</option>';
			}else{
				$languagesListHtml .= '<option value='.$languageCode.'>'.$languageName.'</option>';
			}//end of else		
		}//end of for

		return $languagesListHtml;
	}//end of function

	public function getWhatsAppBusinessTemplateViewUrl() {
		$module = $this->getModule();
		return 'index.php?module='.$this->getModuleName().'&view=WhatsAppBusinessTemplatePopup&record='.$this->getId();
	}//end of function

	public function getEditViewUrl() {
		$module = $this->getModule();
		$recordId = $this->getId();
		$recordModel = Vtiger_Record_Model::getInstanceById($recordId, $module);

		if($recordModel->get('whatsapp_template_type') == 'WhatsApp Business Template'){
			return 'index.php?module='.$this->getModuleName().'&view=WhatsAppBusinessTemplatePopup&record='.$this->getId();
		}else{
			return 'index.php?module='.$this->getModuleName().'&view='.$module->getEditViewName().'&record='.$this->getId();
		}//end of else
	}//end of function

	public function getWhatsAppBusinessTemplateId(){
		global $adb;
		$getWhatsappTemplateQuery = $adb->pquery("SELECT * FROM vtiger_ctwhatsappbusinesstemplates INNER JOIN vtiger_crmentity ON vtiger_crmentity.crmid = vtiger_ctwhatsappbusinesstemplates.ctwhatsappbusinesstemplatesid WHERE vtiger_crmentity.deleted = 0 AND vtiger_ctwhatsappbusinesstemplates.whatsapp_business_template_id IS NOT NULL");
		$whatsappTemplateRows = $adb->num_rows($getWhatsappTemplateQuery);
		$templatesArray = array();
		for ($j=0; $j < $whatsappTemplateRows; $j++) { 
			$templatesID = $adb->query_result($getWhatsappTemplateQuery, $j, 'ctwhatsappbusinesstemplatesid');
			$whatsAppBusinessTemplateId = $adb->query_result($getWhatsappTemplateQuery, $j, 'whatsapp_business_template_id');
			$templatesArray[$templatesID] = $whatsAppBusinessTemplateId;
		}//end of for

		return $templatesArray;
	}//end of function
}