/* * *******************************************************************************
 * The content of this file is subject to the CRMTiger Pro license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is vTiger
 * The Modified Code of the Original Code owned by https://crmtiger.com/
 * Portions created by CRMTiger.com are Copyright(C) CRMTiger.com
 * All Rights Reserved.
 * ****************************************************************************** */
 
jQuery.Class("WhatsAppBusinessTemplates_WhatsAppBusinessTemplates_Js",{

    _SearchIntiatedEventName : 'VT_SEARCH_INTIATED',
    registerAppTriggerEvent : function() {
        var view = app.view();
        jQuery('.app-menu').removeClass('hide');
        var toggleAppMenu = function(type) { 
            var appMenu = jQuery('.app-menu');
            var appNav = jQuery('.app-nav');
            appMenu.appendTo('#page'); 
            appMenu.css({
                'top' : appNav.offset().top + appNav.height(),
                'left' : 0
            });
            if(typeof type === 'undefined') {
                type = appMenu.is(':hidden') ? 'show' : 'hide';
            }
            if(type == 'show') {
                appMenu.show(200, function() {});
            } else {
                appMenu.hide(200, function() {});
            }
        };

        jQuery('.app-trigger, .app-icon, .app-navigator').on('click',function(e){
            e.stopPropagation();
            toggleAppMenu();
        });

        jQuery('html').on('click', function() {
            toggleAppMenu('hide');
        });

        jQuery(document).keyup(function (e) {
            if (e.keyCode == 27) {
                if(!jQuery('.app-menu').is(':hidden')) {
                    toggleAppMenu('hide');
                }
            }
        });

        jQuery('.app-modules-dropdown-container').hover(function(e) {
            var dropdownContainer = jQuery(e.currentTarget);
            jQuery('.dropdown').removeClass('open');
            if(dropdownContainer.length) {
                if(dropdownContainer.hasClass('dropdown-compact')) {
                    dropdownContainer.find('.app-modules-dropdown').css('top', dropdownContainer.position().top - 8);
                } else {
                    dropdownContainer.find('.app-modules-dropdown').css('top', '');
                }
                dropdownContainer.addClass('open').find('.app-item').addClass('active-app-item');
            }
        }, function(e) {
            var dropdownContainer = jQuery(e.currentTarget);
            dropdownContainer.find('.app-item').removeClass('active-app-item');
            setTimeout(function() {
                if(dropdownContainer.find('.app-modules-dropdown').length && !dropdownContainer.find('.app-modules-dropdown').is(':hover') && !dropdownContainer.is(':hover')) {
                    dropdownContainer.removeClass('open');
                }
            }, 500);

        });

        jQuery('.app-item').on('click', function() {
            var url = jQuery(this).data('defaultUrl');
            if(url) {
                window.location.href = url;
            }
        });

        jQuery(window).resize(function() {
            jQuery(".app-modules-dropdown").mCustomScrollbar("destroy");
            app.helper.showVerticalScroll(jQuery(".app-modules-dropdown").not('.dropdown-modules-compact'), {
                setHeight: $(window).height(),
                autoExpandScrollbar: true
            });
            jQuery('.dropdown-modules-compact').each(function() {
                var element = jQuery(this);
                var heightPer = parseFloat(element.data('height'));
                app.helper.showVerticalScroll(element, {
                    setHeight: $(window).height()*heightPer - 3,
                    autoExpandScrollbar: true,
                    scrollbarPosition: 'outside'
                });
            });
        });
        app.helper.showVerticalScroll(jQuery(".app-modules-dropdown").not('.dropdown-modules-compact'), {
            setHeight: $(window).height(),
            autoExpandScrollbar: true,
            scrollbarPosition: 'outside'
        });
        jQuery('.dropdown-modules-compact').each(function() {
            var element = jQuery(this);
            var heightPer = parseFloat(element.data('height'));
            app.helper.showVerticalScroll(element, {
                setHeight: $(window).height()*heightPer - 3,
                autoExpandScrollbar: true,
                scrollbarPosition: 'outside'
            });
        });
    },

    registerGlobalSearch : function() {
        var thisInstance = this;
        jQuery('.search-link .keyword-input').live('keypress',function(e){
            if(e.which == 13) {

                var element = jQuery(e.currentTarget);
                var searchValue = element.val();
                var data = {};
                data['searchValue'] = searchValue;
                element.trigger(thisInstance._SearchIntiatedEventName,data);
            }
        });
    },
    
    addSearchListener : function () {
        jQuery('.search-link .keyword-input').on('VT_SEARCH_INTIATED',function(e,args){
            var val = args.searchValue;
            var url = '?module=Vtiger&view=ListAjax&mode=searchAll&value='+encodeURIComponent(val);
            app.helper.showProgress();
            app.request.get({'url': url}).then(function (error, data) {
                if (error == null) {
                    app.helper.hideProgress();
                    app.helper.loadPageOverlay(data).then(function (modal) {
                        modal.find('.keyword-input').val(jQuery('.keyword-input').val());
                        Vtiger_SearchList_Js.intializeListInstances(modal);
                    });
                }
            });
        });
    },

    registerEventForTaskManagement : function(){
        var globalNav = jQuery('.global-nav');
        globalNav.on("click",".taskManagement",function(e){
            if(jQuery("#taskManagementContainer").length > 0){
                app.helper.hidePageOverlay();
                return false;
            }
            
            let callURL = new URLSearchParams(document.location.search.substring(1));
            let name = callURL.get("module"); // is the string "Jonathan" 
            if(name == 'Billing'){
                return false;
            }

            var params = {
                'module' : 'Calendar',
                'view' : 'TaskManagement',
                'mode' : 'showManagementView'
            }
            app.helper.showProgress();
            app.request.post({"data":params}).then(function(err,data){
                if(err === null){
                    app.helper.loadPageOverlay(data,{'ignoreScroll' : true,'backdrop': 'static'}).then(function(){
                        app.helper.hideProgress();
                        $('#overlayPage').find('.data').css('height','100vh');

                        var taskManagementPageOffset = jQuery('.taskManagement').offset();
                        $('#overlayPage').find(".arrow").css("left",taskManagementPageOffset.left+13);
                        $('#overlayPage').find(".arrow").addClass("show");

                        vtUtils.showSelect2ElementView($('#overlayPage .data-header').find('select[name="assigned_user_id"]'),{placeholder:"User : All"});
                        vtUtils.showSelect2ElementView($('#overlayPage .data-header').find('select[name="taskstatus"]'),{placeholder:"Status : All"});
                        var js = new Vtiger_TaskManagement_Js();
                        js.registerEvents();
                    });
                }else{
                    app.helper.showErrorNotification({"message":err});
                }
            });
        });
    },

    registerQuickCreateEvent : function (){

        var thisInstance = this;
        jQuery("#quickCreateModules,#quickCreateModule1").on("click",".quickCreateModule,.quickCreateModule1",function(e,params){

            var quickCreateElem = jQuery(e.currentTarget);
            var quickCreateUrl = quickCreateElem.data('url');
            var quickCreateModuleName = quickCreateElem.data('name');
            if(quickCreateModuleName == 'Billing'){
                location.reload();
                return false;
            }
            if (typeof params === 'undefined') {
                params = {};
            }
            if (typeof params.callbackFunction === 'undefined') {
                params.callbackFunction = function(data, err) {
                    //fix for Refresh list view after Quick create
                    var parentModule=app.getModuleName();
                    var viewname=app.view();
                    if(((quickCreateModuleName == parentModule) || (quickCreateModuleName == 'Events' && parentModule == 'Calendar')) && (viewname=="List")){
                        var listinstance = app.controller();
                        listinstance.loadListViewRecords();
                    }
                };
            }
            app.helper.showProgress();
            thisInstance.getQuickCreateForm(quickCreateUrl,quickCreateModuleName,params).then(function(data){
                if(data == 'Billing'){
                    location.reload();
                    return false;
                }
                app.helper.hideProgress();
                var callbackparams = {
                    'cb' : function (container){
                        thisInstance.registerPostReferenceEvent(container);
                        app.event.trigger('post.QuickCreateForm.show',form);
                        app.helper.registerLeavePageWithoutSubmit(form);
                        app.helper.registerModalDismissWithoutSubmit(form);
                    },
                    backdrop : 'static',
                    keyboard : false
                }

                app.helper.showModal(data, callbackparams);
                var form = jQuery('form[name="QuickCreate"]');
                var moduleName = form.find('[name="module"]').val();
                var Options= {
                    scrollInertia: 200,
                    autoHideScrollbar: true,
                    setHeight:(jQuery(window).height() - jQuery('form[name="QuickCreate"] .modal-body').find('.modal-header').height() - jQuery('form[name="QuickCreate"] .modal-body').find('.modal-footer').height()- 135),
                }
                app.helper.showVerticalScroll(jQuery('form[name="QuickCreate"] .modal-body'), Options);

                var targetInstance = thisInstance;
                var moduleInstance = Vtiger_Edit_Js.getInstanceByModuleName(moduleName);
                if(typeof(moduleInstance.quickCreateSave) === 'function'){
                    targetInstance = moduleInstance;
                    targetInstance.registerBasicEvents(form);
                }

                vtUtils.applyFieldElementsView(form);
                targetInstance.quickCreateSave(form,params);
            });
        });
    },

    registerPostQuickCreateEvent : function(){
        var thisInstance = this;

        app.event.on("post.QuickCreateForm.show",function(event,form){
            form.find('#goToFullForm').on('click', function(e) {
                window.onbeforeunload = true;
                var form = jQuery(e.currentTarget).closest('form');
                var editViewUrl = jQuery(e.currentTarget).data('editViewUrl');
                if (typeof goToFullFormCallBack != "undefined") {
                    goToFullFormCallBack(form);
                }
                thisInstance.quickCreateGoToFullForm(form, editViewUrl);
            });
        });
    },

        /**
     * Function to navigate from quickcreate to editView Fullform
     * @param accepts form element as parameter
     */
    quickCreateGoToFullForm: function(form, editViewUrl) {
        var formData = form.serializeFormData();
        //As formData contains information about both view and action removed action and directed to view
        delete formData.module;
        delete formData.action;
        delete formData.picklistDependency;
        var formDataUrl = jQuery.param(formData);
        var completeUrl = editViewUrl + "&" + formDataUrl;
        window.location.href = completeUrl;
    },

    getQuickCreateForm: function(url, moduleName, params) {
        var aDeferred = jQuery.Deferred();
        var requestParams = app.convertUrlToDataParams(url);
        jQuery.extend(requestParams, params.data);
        app.request.post({data:requestParams}).then(function(err,data) {
            aDeferred.resolve(data);
        });
        return aDeferred.promise();
    },

    registerPostReferenceEvent : function(container) {
        var thisInstance = this;

        container.find('.sourceField').on(Vtiger_Edit_Js.postReferenceSelectionEvent,function(e,result){
            var dataList = result.data;
            var element = jQuery(e.currentTarget);

            if(typeof element.data('autofill') != 'undefined') {
                thisInstance.autoFillElement = element;
                if(typeof(dataList.id) == 'undefined'){
                    thisInstance.postRefrenceComplete(dataList, container);
                }else {
                    thisInstance.postRefrenceSearch(dataList, container);
                }
            }
        });
    },

    registerEventsForModulefields : function() {
        jQuery('[name="wptemplate_modules"]').on('change', function(e){
            var sourceModuleName = jQuery('[name="wptemplate_modules"]').val();
            var moduleName = app.getModuleName();
            var params = {
                'module' : moduleName,
                'view' : "WhatsAppTemplatesData",
                'mode' : "getModuleFields",
                'sourcemodulename' : sourceModuleName
            }
            
            AppConnector.request(params).then(
                function(data) {
                    jQuery('[name="wptemplate_fields"]').html('');
                    jQuery('[name="wptemplate_fields"]').html(data.result['modulesFieldshtml']);
                }
            );
        });
        jQuery('[name="wptemplate_modules"]').trigger('change');
    },

    registerEventsForModulePlaceHolder : function(container) {
        jQuery('select[name="wptemplate_fields"]').live('change', function(){
            var picklistvalue = jQuery('select[name="wptemplate_fields"]').val();
            var textareavalue = jQuery('textarea[name="wptemplate_text"]').val();
            var textareanewvalue = textareavalue+picklistvalue;
            jQuery('textarea[name="wptemplate_text"]').val(textareanewvalue);
        });
    },

    registerFileElementChangeEvent : function(container) {
        var thisInstance = this;
        jQuery('input[name="wptemplate_image[]"]').live('change', function(e){
            if(e.target.type == "text") return false;
            var moduleName = jQuery('[name="module"]').val();
            if(moduleName == "Products") return false;
            Vtiger_Edit_Js.file = e.target.files[0];
            var element = jQuery('input[name="wptemplate_image[]"]');
            //ignore all other types than file 
            if(element.attr('type') != 'file'){
                    return ;
            }
            var uploadFileSizeHolder = element.closest('.fileUploadContainer').find('.uploadedFileSize');
            var fileSize = e.target.files[0].size;
            var fileName = e.target.files[0].name;
            uploadFileSizeHolder.text(fileName);
        });
    },

    registerWhatsAppTemplate : function(){
        jQuery(document).ready(function(){
            if($('#recordId').val() != ''){
                var headerType = $('#headerType').val();
                headerTypeChangeEvent(headerType, 'load');
                var templateTextCount = $('#templateName').val().length;
                $('span#templateNameCharacterCount').text(templateTextCount+'/512');
                
                var headerTextCount = $('#headerText').val().length;
                $('span#headerTextCount').text(headerTextCount+'/60');

                var bodyTextCount = $('#bodyText').val().length;
                $('span#bodyTextCount').text(bodyTextCount+'/1024');

                var footerTextCount = $('#footerText').val().length;
                $('span#footerTextCount').text(footerTextCount+'/60');

                if(bodyVariableValue != null){
                    var bodyVariableCnt = 0;
                    $.each(bodyVariableValue, function(index,value){
                        bodyVariableCnt = bodyVariableCnt + 1;
                        var table = $('#tblBodyContent'),
                        newRow = $('<tr id="row'+bodyVariableCnt+'" class="bodyVariableRow">');
                        variableNumber = "{{"+bodyVariableCnt+"}}";

                        var inputName = 'bodyVariableVal_'+bodyVariableCnt;

                        var  placeholderText = app.vtranslate('LBL_ENTER_CONTENT_FOR')+variableNumber; 
                        newRow.append("<td><span>"+variableNumber+"</span><input type='text' class='inputElement' name='"+inputName+"' id='"+inputName+"' placeholder='"+placeholderText+"' value='"+value+"' style='width:60%;'></td>");
                        table.append(newRow);
                    });//end of each
                    $("#bodyVariableRowVal").val(bodyVariableCnt);
                }//end of if

                if(buttonsData != null){
                    var customButtonCnt = vistWebsiteButtonCnt = callPhoneNumberButtonCnt = copyOfferCodeButtonCnt = actionButton = 0;
                    $.each(buttonsData, function(index,value){
                        if(value.type == 'QUICK_REPLY'){
                            customButtonCnt = customButtonCnt + 1;
                            addWhatsAppTemplateButton('quick_replay_button', customButtonCnt, value.text, 0);
                        }else if(value.type == 'URL'){
                            vistWebsiteButtonCnt = vistWebsiteButtonCnt + 1;
                            addWhatsAppTemplateButton('Visit Website', vistWebsiteButtonCnt, value, actionButton);
                            actionButton = 1;
                        }else if(value.type == 'COPY_CODE'){
                            copyOfferCodeButtonCnt = copyOfferCodeButtonCnt + 1;
                            addWhatsAppTemplateButton('Copy Offer Code', copyOfferCodeButtonCnt, value.example, actionButton);
                            actionButton = 1;
                        }else if(value.type == 'PHONE_NUMBER'){
                            callPhoneNumberButtonCnt = callPhoneNumberButtonCnt + 1;
                            addWhatsAppTemplateButton('Call Phone Number', callPhoneNumberButtonCnt, value, actionButton);
                            actionButton = 1;
                        }//end of else if
                    });//end of function
                }//end of if
            }//end of if
        });//end of function

        $('#templateName').on('keypress', function(e){
            $('#templateName').removeClass('input-error');
            var keyCode = e.which;

            // Allow lowercase letters (97 to 122) and underscore (95)
            if ((keyCode >= 97 && keyCode <= 122) || keyCode === 95 || (keyCode > 48 && keyCode < 57)) {
                return true; // Allow the keypress
            } else {
                e.preventDefault(); // Prevent the keypress
                app.helper.showErrorNotification({title: 'Error', message: app.vtranslate('LBL_TEMPLATE_NAME_VALIDATION')});
            }//end of else
        });//end of function

        $('#templateName').live('keyup', function(){
            var countChar = $(this).val().length;
            $('span#templateNameCharacterCount').text(countChar+'/512');
        });//end of function

        $('#headerText').live('keyup', function(){
            var countChar = $(this).val().length;
            $('span#headerTextCount').text(countChar+'/60');
        });//end of function

        $('#bodyText').live('keyup', function(){
            var countChar = $(this).val().length;
            $('span#bodyTextCount').text(countChar+'/1024');
            $('#bodyText').removeClass('input-error');
        });//end of function

        $('#footerText').live('keyup', function(){
            var countChar = $(this).val().length;
            $('span#footerTextCount').text(countChar+'/60');
        });//end of function

        $('.customButtonText').live('keyup', function(){
            var charCnt = $(this).val().length;
            $(this).prev('span').text(charCnt+'/25');
        });//end of function

        $('.visitWebsiteButtonText').live('keyup', function(){
            var charCnt = $(this).val().length;
            $(this).prev('span').text(charCnt+'/25');
        });//end of function

        $('.visitWebsiteURL').live('keyup', function(){
            var charCnt = $(this).val().length;
            $(this).prev('span').text(charCnt+'/200');
        });//end of function

        $('.phoneNumberVal').live('keyup', function(){
            var charCnt = $(this).val().length;
            $(this).prev('span').text(charCnt+'/20');
        });//end of function

        $('.offerCode').live('keyup', function(){
            var charCnt = $(this).val().length;
            $(this).prev('span').text(charCnt+'/15');
        });//end of function

        $('#headerType').live('change', function(){
            var headerType = $(this).val();
            headerTypeChangeEvent(headerType, 'change');
        });//end of function

        $('#btnAddHeaderVariable').live('click', function(){
            var countChar = $('#headerText').val().length;
            if(countChar <= 55){
                var headerText = $('#headerText').val()
                if(!headerText.includes("{{1}}")){
                    var updatedHeaderVal = headerText + '{{1}}';
                    $('#headerText').val(updatedHeaderVal);
                    jQuery('.headerContentLabel, .headerVariableBlock, #headerVariableValue').show();
                }//end of if
                var countChar = $('#headerText').val().length;
                $('span#headerTextCount').text(countChar+'/60');
            }else{
                app.helper.showErrorNotification({title: 'Error', message: app.vtranslate('LBL_HEADER_TEXT_MAXIMUM_CHARACTERS')});
                return false;
            }//end of else
        });//end of function

        $('#headerText').live('keyup', function(){
            var headerTextVal = $(this).val();
            headerTextKeyUpEvent(headerTextVal);
        });//end of function

        $('#uploadHeaderMedia').live('change', function(){
            $('.headerImageDelete').hide();
            var mediaType = $('input[name="mediaType[]"]:checked').val();
            if(mediaType == '' || mediaType == undefined){
                app.helper.showErrorNotification({title: 'Error', message: app.vtranslate('LBL_MEDIA_TYPE_EMPTY')});
                $('#uploadHeaderMedia, #headerMediaFileType, #headerMediaFileLength').val('');
                $('div.uploadedFileName').text('');
            }else{
                var $input = $(this);
                var files = $input[0].files;
                var filename = files[0].name;
                var fileMimeType = files[0].type;
                var fileSize = files[0].size;
                
                $('#headerMediaFileType').val(fileMimeType);
                $('#headerMediaFileLength').val(fileSize);
                var extension = filename.substr(filename.lastIndexOf("."));
                var mimeTypeValid = 0;
                if(mediaType == 'IMAGE'){
                    if(fileMimeType != 'image/jpeg' && fileMimeType != 'image/jpg' && fileMimeType != 'image/png'){
                        mimeTypeValid = 1;
                    }//end of if
                }else if(mediaType == 'VIDEO'){
                    if(fileMimeType != 'video/mp4'){
                        mimeTypeValid = 1;
                    }//end of if
                }else if(mediaType == 'DOCUMENT'){
                    if(fileMimeType != 'application/pdf'){
                        mimeTypeValid = 1;
                    }//end of if
                }//end of else if

                if(mimeTypeValid == 1){
                    app.helper.showErrorNotification({title: 'Error', message: app.vtranslate('LBL_HEADER_MEDIA_TYPE_VALIDATION')});
                    $('#uploadHeaderMedia, #headerMediaFileType, #headerMediaFileLength').val('');
                    $('div.uploadedFileName').text('');
                }else{
                    var reader = new FileReader();
                    reader.addEventListener('load', function() {
                        var res = reader.result;
                        jQuery('[name="headerMediaData"]').val(res);
                    });
                    var fileProperty = document.getElementById('uploadHeaderMedia').files[0];
                    reader.readAsDataURL(fileProperty);
                    $('div.uploadedFileName').text('['+filename+']');
                }//end of else
            }//end of else
        });//end of function

        $('#saveWhatsAppBusiness').live('click', function(){
            saveWhatsAppBusinessTemplateConfiguration('saveWhatsAppBusiness');
        });//end of function

        $('#btnAddBodyVariable').live('click', function(){
            var countChar = $('#bodyText').val().length;

            if(countChar <= 1019){
                var row = parseInt($('#bodyVariableRowVal').val());
                var rowNumber = row + 1;
                var table = $('#tblBodyContent'),
                newRow = $('<tr id="row'+rowNumber+'" class="bodyVariableRow">');
                variableNumber = "{{"+rowNumber+"}}";

                var inputName = 'bodyVariableVal_'+rowNumber;

                var  placeholderText = app.vtranslate('LBL_ENTER_CONTENT_FOR')+variableNumber; 
                newRow.append("<td><span>"+variableNumber+"</span><input type='text' class='inputElement' name='"+inputName+"' id='"+inputName+"' placeholder='"+placeholderText+"' style='width:60%;'></td>");
                table.append(newRow);
                row += 1;
                $("#bodyVariableRowVal").val(row);

                var bodyText = $('#bodyText').val()
                if(!bodyText.includes(variableNumber)){
                    var updatedBodyVal = bodyText + variableNumber;
                    $('#bodyText').val(updatedBodyVal);
                }///end of if

                var countChar = $('#bodyText').val().length;
                $('span#bodyTextCount').text(countChar+'/1024');
            }else{
                app.helper.showErrorNotification({title: 'Error', message: app.vtranslate('LBL_BODY_TEXT_MAXIMUM_CHARACTERS')});
                return false;
            }//end of else
        });//end of function

        $('#bodyText').live('keyup', function(){
            var bodyTextVal = $(this).val();
            var bodyVariableRowVal = $('#bodyVariableRowVal').val();
            for(var i=1;i<=bodyVariableRowVal;i++){
                if(!bodyTextVal.includes('{{'+i+'}}')){
                    $('#bodyVariableVal_'+i).closest('tr').css('display', 'none');
                }else{
                    if($('#bodyVariableVal_'+i).length == 1){
                        $('#bodyVariableVal_'+i).closest('tr').removeAttr('style');
                    }//end of if
                }//end of else
            }//end of for
        });//end of function
        
        $('#buttonType').on('change', function(){
            var buttonTypeVal = $('#buttonType').val();
            addWhatsAppTemplateButtonRow(buttonTypeVal);
        });//end of function

        $('.addButton').live('click', function(){
            var buttonTypeVal = $(this).attr('data-id');
            addWhatsAppTemplateButtonRow(buttonTypeVal);
        });//end of function

        $('.urlType').live('change', function(){
            var currentId = $(this).attr('id');
            urlData = currentId.split('_');
            var cnt = urlData[1];
            if($(this).val() == 'Dynamic'){
                $('.addSampleURL_'+cnt).show();
                var websiteURL = $('#visitWebisteURL_'+cnt).val()
                var variableNumber = '{{1}}';
                if(!websiteURL.includes(variableNumber)){
                    var updatedWebsiteURLVal = websiteURL + variableNumber;
                    $('#visitWebisteURL_'+cnt).val(updatedWebsiteURLVal);
                }///end of if
                var charCnt = $('#visitWebisteURL_'+cnt).val().length;
                $('#visitWebisteURL_'+cnt).prev('span').text(charCnt+'/200');
            }else{
                var websiteURL = $('#visitWebisteURL_'+cnt);
                websiteURL.val(websiteURL.val().replace("{{1}}", " "));
                $('.addSampleURL_'+cnt).hide();
                $('input.addSampleURL_'+cnt).val('');
            }//end of else
        });//end of function

        $('.deleteCondition').live('click', function(){
            var btnNo = ($(this).closest('span').attr('data-cnt'));
            $(this).closest('div').hide();
            $('#customButtonDeleted_'+btnNo).val('1');

            var displayBlock = 0;
            $('.dynamicButtonBox .dynamicButtonBoxData').each(function(){
                if($(this).css('display') == 'block'){
                    displayBlock = 1;
                }//end of if
            });//end of function
            
            if(displayBlock == 0){
                $('.dynamicButtonBox').hide();
            }//end of if

            var totButtonsCnt = totalButtonsCount();
            if(totButtonsCnt < 10){
                var vistWebsiteButtonCnt = parseInt($('#vistWebsiteButtonCnt').val());
                var visitWebsiteCnt = 0;
                for(var i=1;i<=vistWebsiteButtonCnt;i++){
                    if($('#visitWebsiteRow_'+i).is(':visible')){
                        visitWebsiteCnt++;
                    }//end of if
                }//end of for
                if(visitWebsiteCnt >= 2){
                    $('.addButton[data-id="quick_replay_button"]').attr('disabled',false);
                }else{
                    $('.addButton').attr('disabled', false);
                }//end of else
            }//end of if
        });//end of function

        $('.deleteConditionVisitWebsite').live('click', function(){
            var btnNo = ($(this).closest('span').attr('data-cnt'));
            $(this).closest('div').parent('div').hide();
            $(this).closest('div').parent('div').parent('div').hide();
            $(this).closest('div').parent('div').parent('div').parent('div').hide();
            $('#visitWebsiteDeleted_'+btnNo).val('1');

            var displayNoneBlockFlag = 0;
            $('.action-div .white-wrap-div .visitWebsiteInnerDiv').each(function(){
                if($(this).css('display') == 'block'){
                    displayNoneBlockFlag = 1;
                }//end of if
            });//end of function

            if(displayNoneBlockFlag == 0){
                $('.visitWebsiteInnerDiv').parent('div').hide();
            }//end of if

            var displayBlock = 0;
            $('.action-div .white-wrap-div').each(function(){
                if($(this).css('display') == 'block'){
                    displayBlock = 1;
                }//end of if
            });//end of function

            if(displayBlock == 0){
                $('.action-div').hide();
            }//end of if

            var totButtonsCnt = totalButtonsCount();
            if(totButtonsCnt < 10){
                var vistWebsiteButtonCnt = parseInt($('#vistWebsiteButtonCnt').val());
                var visitWebsiteCnt = 0;
                for(var i=1;i<=vistWebsiteButtonCnt;i++){
                    if($('#visitWebsiteRow_'+i).is(':visible')){
                        visitWebsiteCnt++;
                    }//end of if
                }//end of for
                if(visitWebsiteCnt >= 2){
                    $('.addButton[data-id="quick_replay_button"]').attr('disabled',false);
                }else{
                    $('.addButton').attr('disabled', false);
                }//end of else
            }//end of if

        });//end of function

        $('.deleteConditionCopyOfferCode').live('click', function(){
            var btnNo = ($(this).closest('span').attr('data-cnt'));
            $(this).closest('div').parent('div').hide();
            $(this).closest('div').parent('div').parent('div').hide();
            $(this).closest('div').parent('div').parent('div').parent('div').hide();
            $('#copyOfferCodeDeleted_'+btnNo).val('1');

            var displayBlock = 0;
            $('.action-div .white-wrap-div').each(function(){
                if($(this).css('display') == 'block'){
                    displayBlock = 1;
                }//end of if
            });//end of function

            if(displayBlock == 0){
                $('.action-div').hide();
            }//end of if

            var totButtonsCnt = totalButtonsCount();
            if(totButtonsCnt < 10){
                var vistWebsiteButtonCnt = parseInt($('#vistWebsiteButtonCnt').val());
                var visitWebsiteCnt = 0;
                for(var i=1;i<=vistWebsiteButtonCnt;i++){
                    if($('#visitWebsiteRow_'+i).is(':visible')){
                        visitWebsiteCnt++;
                    }//end of if
                }//end of for
                if(visitWebsiteCnt >= 2){
                    $('.addButton[data-id="quick_replay_button"]').attr('disabled',false);
                }else{
                    $('.addButton').attr('disabled', false);
                }//end of else
            }//end of if
        });//end of function

        $('.deleteConditionCallPhoneNumber').live('click', function(){
            var btnNo = ($(this).closest('span').attr('data-cnt'));
            $(this).closest('div').parent('div').hide();
            $(this).closest('div').parent('div').parent('div').hide();
            $(this).closest('div').parent('div').parent('div').parent('div').hide();
            $('#callPhoneNumberDeleted_'+btnNo).val('1');

            var displayBlock = 0;
            $('.action-div .white-wrap-div').each(function(){
                if($(this).css('display') == 'block'){
                    displayBlock = 1;
                }//end of if
            });//end of function
            
            if(displayBlock == 0){
                $('.action-div').hide();
            }//end of if

            var totButtonsCnt = totalButtonsCount();
            if(totButtonsCnt < 10){
                var vistWebsiteButtonCnt = parseInt($('#vistWebsiteButtonCnt').val());
                var visitWebsiteCnt = 0;
                for(var i=1;i<=vistWebsiteButtonCnt;i++){
                    if($('#visitWebsiteRow_'+i).is(':visible')){
                        visitWebsiteCnt++;
                    }//end of if
                }//end of for
                if(visitWebsiteCnt >= 2){
                    $('.addButton[data-id="quick_replay_button"]').attr('disabled',false);
                }else{
                    $('.addButton').attr('disabled', false);
                }//end of else
            }//end of if
        });//end of function

        $('input[name="mediaType[]"]').live('change', function(){
            $('.uploadedFileName').text('');
            $('#uploadHeaderMedia').val('');
        });//end of function

        //called when key is pressed in textbox
        $(".phoneNumberVal").live('keypress',function (e) {
            //if the letter/character is not digit then display error and don't type anything
            if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
                //display error message
                app.helper.showErrorNotification({title: 'Error', message: app.vtranslate('LBL_ONLY_ALLOW_DIGIT_NUMBER')});
                        return false; 
                return false;
            }//end of if
        });//end of function

        function totalButtonsCount(){
            var totButtons = 0;
            var customButtonCnt = parseInt($('#customButtonCnt').val());
            var vistWebsiteButtonCnt = parseInt($('#vistWebsiteButtonCnt').val());
            var callPhoneNumberButtonCnt = parseInt($('#callPhoneNumberButtonCnt').val());
            var copyOfferCodeButtonCnt = parseInt($('#copyOfferCodeButtonCnt').val());
            
            for(var i=1;i<=customButtonCnt;i++){
                if($('#dynamicButtonBox'+i).is(':visible')){
                    totButtons++;
                }//end of if
            }//end of for

            for(var i=1;i<=vistWebsiteButtonCnt;i++){
                if($('#visitWebsiteRow_'+i).is(':visible')){
                    totButtons++;
                }//end of if
            }//end of for

            for(var i=1;i<=callPhoneNumberButtonCnt;i++){
                if($('#callPhoneNumberRow_'+i).is(':visible')){
                    totButtons++;
                }//end of if
            }//end of for

            for(var i=1;i<=copyOfferCodeButtonCnt;i++){
                if($('#copyOfferCodeRow_'+i).is(':visible')){
                    totButtons++;
                }//end of if
            }//end of for

            return totButtons;
        }//end of function

        function addWhatsAppTemplateButtonRow(buttonTypeVal){
            var buttonCnt = totButtons = actionButton = 0;
            
            totButtons = totalButtonsCount();
            
            if(totButtons >= 10){
                app.helper.showErrorNotification({title: 'Error', message: app.vtranslate('LBL_TEMPLATES_BUTTON_LIMIT')});
                    $('#buttonType').val('').select2();
                    return false;
            }else{
                if(buttonTypeVal == 'quick_replay_button'){
                    buttonCnt = parseInt($('#customButtonCnt').val());
                    buttonCnt = buttonCnt + 1;
                }else if(buttonTypeVal == 'Visit Website'){
                    var cnt = 1;
                    buttonCnt = parseInt($('#vistWebsiteButtonCnt').val());
                    buttonCnt = buttonCnt + 1;
                    for(var i=1;i<buttonCnt;i++){
                        if($('#visitWebsiteRow_'+i).is(':visible')){
                            cnt++;
                        }//end of if
                    }//end of for
                    if(cnt > 2){
                        //$('.addButton[data-id="Visit Website"]').attr('disabled',true);
                        app.helper.showErrorNotification({title: 'Error', message: app.vtranslate('LBL_VISIT_WEBSITE_MAXIMUM')});
                        $('#buttonType').val('').select2();
                        return false;
                    }//end of if
                }else if(buttonTypeVal == 'Call Phone Number'){
                    var cnt = 1;
                    buttonCnt = parseInt($('#callPhoneNumberButtonCnt').val());
                    buttonCnt = buttonCnt + 1;
                    for(var i=1;i<buttonCnt;i++){
                        if($('#callPhoneNumberRow_'+i).is(':visible')){
                            cnt++;
                        }//end of if
                    }//end of for
                    if(cnt > 1){
                        app.helper.showErrorNotification({title: 'Error', message: app.vtranslate('LBL_CALL_PHONE_NUMBER_MAXIMUM')});
                        $('#buttonType').val('').select2();
                        return false;
                    }//end of if
                }else if(buttonTypeVal == 'Copy Offer Code'){
                    var cnt = 1;
                    buttonCnt = parseInt($('#copyOfferCodeButtonCnt').val());
                    buttonCnt = buttonCnt + 1;
                    for(var i=1;i<buttonCnt;i++){
                        if($('#copyOfferCodeRow_'+i).is(':visible')){
                            cnt++;
                        }//end of if
                    }//end of for
                    if(cnt > 1){
                        app.helper.showErrorNotification({title: 'Error', message: app.vtranslate('LBL_COPY_OFFER_CODE_MAXIMUM')});
                        $('#buttonType').val('').select2();
                        return false;
                    }//end of if
                }//end of else if

                if($('.action-div').length > 0){
                    actionButton = 1;
                }//end of if

                addWhatsAppTemplateButton(buttonTypeVal, buttonCnt,'', actionButton);
                $('#buttonType').val('').select2();
            }//end of else
        }//end of function

        function headerTypeChangeEvent(headerType, eventType){
            jQuery('.headerContentLabel, .headerVariableBlock, #headerVariableValue').hide();

            if(eventType == 'change'){
                $('#headerText, #headerVariableValue, #uploadMedia').val('');
                $('div.uploadedFileName').text('');
                $("[name='mediaType[]']").prop('checked', false);
            }//end of if
            
            if(headerType == 'TEXT'){
                jQuery('.mediaTypeRadioButton, .orOperationTr, .uploadMedia, .headerContentLabel, .headerVariableBlock').hide();
                jQuery('#btnAddHeaderVariable, #headerText').closest('tr').show();

                if(eventType == 'load'){
                    headerTextKeyUpEvent($('#headerText').val());
                }//end of if
            }else{
                jQuery('.mediaTypeRadioButton, .orOperationTr, .uploadMedia').show();
                jQuery('#btnAddHeaderVariable, #headerText').closest('tr').hide();
            }//end of else
        }//end of function

        function headerTextKeyUpEvent(headerTextVal){
            if(headerTextVal.includes("{{1}}")){
                $('.headerContentLabel, .headerVariableBlock, #headerVariableValue').show();
            }else{
                $('.headerContentLabel, .headerVariableBlock').hide();
                $('#headerVariableValue').val('');
            }//end of else
        }//end of function

        function addWhatsAppTemplateButton(buttonTypeVal, buttonCnt, textVal, actionButton){
            var moduleName = app.getModuleName();
            var params = {
                'module': moduleName,
                'view' : "WhatsAppTemplatesData",
                'mode' : "getWhatsAppTemplateButton",
                'buttonTypeVal' : buttonTypeVal, 
                'buttonCnt': buttonCnt,
                'buttonData' : textVal,
                'actionButton': actionButton,
            }
            
            AppConnector.request(params).then(
                function(data) {
                    if(buttonTypeVal == 'quick_replay_button'){
                        var boxLength = $('table#dynamicButton > tbody > tr > td').find('.dynamicButtonBox').length;
                        if(boxLength == 0){
                            $('table#dynamicButton > tbody > tr > td').append(data.result);
                        }else{
                            $('.dynamicButtonBox').show();
                            $('.dynamicButtonBox .addButtonDiv').before(data.result);
                        }//end of else
                        $('#customButtonCnt').val(buttonCnt);
                    }else if(buttonTypeVal == 'Visit Website'){
                        var boxLength = $('table#dynamicButton > tbody > tr > td').find('.action-div').length;

                        if(boxLength == 0){
                            $('table#dynamicButton > tbody > tr > td').append(data.result);
                        }else{
                            $('.action-div').show();
                            $('.action-div .white-wrap-div.visitWebsiteDiv').show();
                            $('.action-div .white-wrap-div.visitWebsiteDiv .addButtonDiv').before(data.result);
                        }//end of else
                        if($('#visitWebisteButtonURLType_'+buttonCnt).val() == 'Static'){
                            $('.addSampleURL_'+buttonCnt).hide();
                        }//end of if
                        $('#vistWebsiteButtonCnt').val(buttonCnt);
                        var cnt = 1;
                        for(var i=1;i<buttonCnt;i++){
                            if($('#visitWebsiteRow_'+i).is(':visible')){
                                cnt++;
                            }//end of if
                        }//end of for
                        if(cnt >= 2){
                            $('.addButton[data-id="Visit Website"]').attr('disabled',true);
                        }//end of if
                    }else if(buttonTypeVal == 'Copy Offer Code'){
                        var boxLength = $('table#dynamicButton > tbody > tr > td').find('.action-div').length;
                        if(boxLength == 0){
                            $('table#dynamicButton > tbody > tr > td').append(data.result);
                        }else{
                            $('.action-div').show();
                            $('.action-div').append(data.result);
                        }//end of else
                        $('#copyOfferCodeButtonCnt').val(buttonCnt);
                    }else if(buttonTypeVal == 'Call Phone Number'){
                        var boxLength = $('table#dynamicButton > tbody > tr > td').find('.action-div').length;

                        if(boxLength == 0){
                            $('table#dynamicButton > tbody > tr > td').append(data.result);
                        }else{
                            $('.action-div').show();
                            $('.action-div').append(data.result);
                        }//end of else
                        $('#callPhoneNumberButtonCnt').val(buttonCnt);
                    }//end of else if

                    var totButtonsCnt = totalButtonsCount();
                    if(totButtonsCnt >=10){
                        $('.addButton').attr('disabled', true);
                    }
                }//end of function
            );//end of function
        }//end of function

        $('#templateCategory').on('change', function(){
            var element = $('#templateCategory');
            element = app.helper.getSelect2FromSelect(element);
            $(element).removeClass('input-error');
        });//end of function

        $('#templateLanguage').on('change', function(){
            var element = $('#templateLanguage');
            element = app.helper.getSelect2FromSelect(element);
            $(element).removeClass('input-error');
        });//end of function

        $('.inputErrorClass').live('keypress', function(){
            if($(this).hasClass('input-error')){
                $(this).removeClass('input-error');
            }//end of if
        });//end of function

        function saveWhatsAppBusinessTemplateConfiguration(saveType){
            var moduleName = app.getModuleName();
            var templateName = $('#templateName').val();
            var templateCategory = $('#templateCategory').val();
            var templateLanguage = $('#templateLanguage').val();
            var bodyText = $('#bodyText').val();
            if($('#headerType').val() == 'TEXT'){
                if($('#headerText').val().includes('{{1}}')){
                    if($('#headerVariableValue').val() == ''){
                        app.helper.showErrorNotification({title: 'Error', message: app.vtranslate('LBL_HEADER_VARIABLE_VALUE_EMPTY')});
                        return false;
                    }//end of if
                }//end of if
            }else if($('#headerType').val() == 'MEDIA'){
                var mediaType = $('input[name="mediaType[]"]:checked').val();
                if(mediaType != '' && $('#headerMediaPath').val() == ''){
                    var fileProperty = document.getElementById('uploadHeaderMedia').files[0]
                    if(fileProperty === undefined){
                        app.helper.showErrorNotification({title: 'Error', message: app.vtranslate('LBL_PLEASE_UPLOAD_MEDIA')});
                        return false; 
                    }//end of if
                }//end of if
            }//end of else if

            var customButtonCnt = parseInt($('#customButtonCnt').val());
            var vistWebsiteButtonCnt = parseInt($('#vistWebsiteButtonCnt').val());
            var callPhoneNumberButtonCnt = parseInt($('#callPhoneNumberButtonCnt').val());
            var copyOfferCodeButtonCnt = parseInt($('#copyOfferCodeButtonCnt').val());

            var buttonValCheck = 0;
            for(var i=1;i<=customButtonCnt;i++){
                if($('#dynamicButtonBox'+i).is(':visible')){
                    if($('#customButtonText_'+i).val() == ''){
                        $('#customButtonText_'+i).addClass('input-error');
                        buttonValCheck = 1;
                    }//end of if
                }//end of if
            }//end of for

            for(var i=1;i<=vistWebsiteButtonCnt;i++){
                if($('#visitWebsiteRow_'+i).is(':visible')){
                    if($('#visitWebisteButtonText_'+i).val() == ''){
                        $('#visitWebisteButtonText_'+i).addClass('input-error');
                        buttonValCheck = 1;
                    }//end of if

                    if($('#visitWebisteButtonURLType_'+i).val() == 'Dynamic'){
                        if($('#visitWebsiteSampleURL_'+i).val() == ''){
                            $('#visitWebsiteSampleURL_'+i).addClass('input-error');
                            buttonValCheck = 1;
                        }//end of if
                    }else{
                        if($('#visitWebisteURL_'+i).val() == ''){
                            $('#visitWebisteURL_'+i).addClass('input-error');
                            buttonValCheck = 1;
                        }//end of if
                    }//end of if
                }//end of if
            }//end of for

            for(var i=1;i<=callPhoneNumberButtonCnt;i++){
                if($('#callPhoneNumberRow_'+i).is(':visible')){
                    if($('#callPhoneNumberButtonText_'+i).val() == '' || $('#phoneNumber_'+i).val() == ''){
                        if($('#callPhoneNumberButtonText_'+i).val() == ''){
                            $('#callPhoneNumberButtonText_'+i).addClass('input-error');
                        }//end of if
                        if($('#phoneNumber_'+i).val() == ''){
                            $('#phoneNumber_'+i).addClass('input-error');
                        }//end of if
                        buttonValCheck = 1;
                    }//end of if
                }//end of if
            }//end of for

            for(var i=1;i<=copyOfferCodeButtonCnt;i++){
                if($('#copyOfferCodeRow_'+i).is(':visible')){
                    if($('#offerCodeText_'+i).val() == ''){
                        $('#offerCodeText_'+i).addClass('input-error');
                        buttonValCheck = 1;
                    }//end of if
                }//end of if
            }//end of for

            
            if(templateName != '' && templateCategory != '' && templateLanguage != '' && bodyText != '' && buttonValCheck != 1){
                var formDetails = $('#whatsAppBusinessEditView').serialize();
                var fileProperty = document.getElementById('uploadHeaderMedia').files[0];

                if(fileProperty === undefined){
                    var fileName = '';
                }else{
                    var reader = new FileReader();
                    reader.addEventListener('load', function() {
                        var res = reader.result;
                        jQuery('[name="headerMediaData"]').val(res);
                    });

                    reader.readAsDataURL(fileProperty);
                    var fileName = fileProperty.name;
                }//end of else
                var base64imagedata = jQuery('[name="headerMediaData"]').val();
                
                var params = {
                        'module' : moduleName,
                        'view' : "WhatsAppTemplatesData",
                        'mode' : "saveWhatsAppBusinessConfiguration",
                        'formData' : formDetails,
                        'base64imagedata' : base64imagedata, 
                        'fileName' : fileName,
                        'saveType': saveType
                        };
                var progressIndicatorElement = jQuery.progressIndicator({
                    'position' : 'html',
                    'blockInfo' : {
                        'enabled' : true
                    }
                });//ebd of function

                AppConnector.request(params).then(
                    function(data) {
                        progressIndicatorElement.progressIndicator({
                            'mode' : 'hide'
                        });//ebd of function

                        if(data!= '' && data.result != ''){
                            if(saveType == 'savePreview'){
                                if(data.result.errorMessage != ''){
                                    app.helper.showErrorNotification({title: 'Error', message: JSON.stringify(data.result.errorMessage)});
                                    return false;  
                                }else{
                                    $('.previewDiv').show();
                                    $('.previewModelBody').remove();
                                    $('.previewDiv').append(data.result.previewHtml);
                                    $('#recordId').val(data.result.recordId);
                                }
                            }else{
                                app.helper.showErrorNotification({title: 'Error', message: JSON.stringify(data.result.errorMessage)});
                                return false;
                            }//end of else
                        }else{
                            app.helper.showSuccessNotification({title: 'Sucess', message: app.vtranslate('LBL_WHATSAPP_BUSINESS_TEMPLATE_SAVE')});
                            window.location.href="index.php?module="+moduleName+"&view=List";
                        }//end of else
                    }//end of function
                );//end of function
            }else{
                if(templateName == ''){
                    $('#templateName').addClass('input-error');
                }//end of if

                if(templateCategory == ''){
                    var element = $('#templateCategory');
                    element = app.helper.getSelect2FromSelect(element);
                    $(element).addClass('input-error');
                }//end of if

                if(templateLanguage == ''){
                    var element = $('#templateLanguage');
                    element = app.helper.getSelect2FromSelect(element);
                    $(element).addClass('input-error');
                }//end of if

                if(bodyText == ''){
                    $('#bodyText').addClass('input-error');
                }//end of if

                //app.helper.showErrorNotification({title: 'Error', message: app.vtranslate('LBL_REQUIRED_FIELD_VALIDATION')});
                return false;
            }//end of else
        }//end of function

        $('#savePreviewTemplate').live('click', function() {
            saveWhatsAppBusinessTemplateConfiguration('savePreview');
        });//end of function

        $('.headerImageDelete').on('click', function(){
            $('.uploadedFileName, .uploadedFileSize').text('');
            $('.uploadedFileSize').text('');
            $('#uploadHeaderMedia, #headerMediaPath, #headerMediaFileType, #headerMediaFileLength, #headerMediaData').val('');        
            $('.headerImageDelete').hide();
        });//end of function

        $('#previewOk').live('click', function(){
            var moduleName = app.getModuleName();
            app.helper.showSuccessNotification({title: 'Sucess', message: app.vtranslate('LBL_WHATSAPP_BUSINESS_TEMPLATE_SAVE')});
            window.location.href="index.php?module="+moduleName+"&view=List";
        });//end of function
    },

    registerUpdateWhatsAppTemplateStatus: function(){
        var moduleName = app.getModuleName();
        var params = {
            'module': moduleName,
            'view' : "WhatsAppTemplatesData",
            'mode' : "updateWhatsAppTemplateStatus",
        }
        var progressIndicatorElement = jQuery.progressIndicator({
            'position' : 'html',
            'blockInfo' : {
                'enabled' : true
            }
        });//end of function
        
        AppConnector.request(params).then(
            function(data) {
                progressIndicatorElement.progressIndicator({
                    'mode' : 'hide'
                });
                if(data.result != ''){
                    app.helper.showErrorNotification({title: 'Error', message: data.result});
                }//end of if
            }//end of function
        );//end of function
    },

    /**
     * Registered the events for this page
     */
    registerEvents : function(form) {
        var thisInstance = this;
        if(app.getViewName() == 'Edit'){
            this.registerEventsForModulefields();
            this.registerEventsForModulePlaceHolder();
            this.registerFileElementChangeEvent(form);
            $('[name="category"], [name="language"], [name="header_text"],[name="header_type"], [name="header_variable_value"], [name="media_type"], [name="media_file_path"], [name="footer_text"], [name="whatsapp_business_template_id"], [name="whatsapp_template_status"]').closest('td').hide();
            $('[name="category"], [name="language"], [name="header_text"], [name="header_type"], [name="header_variable_value"], [name="media_type"], [name="media_file_path"], [name="footer_text"], [name="whatsapp_business_template_id"], [name="whatsapp_template_status"]').closest('td').prev().hide();
            $('[name="button_content"], [name="body_content"], [name="body_variable_value"]').parent().parent().parent().hide();
        }else if(app.getViewName() == 'WhatsAppBusinessTemplatePopup'){
            this.registerAppTriggerEvent();
            this.registerGlobalSearch();
            this.addSearchListener();
            this.registerEventForTaskManagement();
            this.registerQuickCreateEvent();
            this.registerPostQuickCreateEvent();
            this.registerWhatsAppTemplate();
        }else if(app.getViewName() == 'List'){
            this.registerUpdateWhatsAppTemplateStatus();
        }//end of else if
    }    
});

jQuery(document).ready(function(){
    var thisInstance = new WhatsAppBusinessTemplates_WhatsAppBusinessTemplates_Js();
    thisInstance.registerEvents(); 
    
});
