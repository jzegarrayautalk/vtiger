<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- FONT AWESOME -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- GOOGLE FONTS-->
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700;800&display=swap" rel="stylesheet">
</head>
<body>
    <div class="whatsapp-business-template">
    	<p class="info-line">{vtranslate('LBL_SELECT_TEMPLATE_TYPE', $MODULE)}</p>
        <div class="helpDiv">
            <a href="https://kb.crmtiger.com/article-categories/whatsapp-business-integration-for-vtiger/" target="_blank">
                <p><img src="layouts/v7/modules/CTWhatsAppBusiness/image/help.png" title="{vtranslate('LBL_HELP', $MODULE)}"></p>
            </a>
        </div>
    	<div class="features">
            <div class="container">
                <div class="features-wrapper" style="justify-content: space-evenly;">
                    <div class="features-wrapper-section features-wrapper-section-1" style="width: 20%;">
                        <div class="features-wrapper-section-box">
                            <h3 style="text-align: center;"><a href="index.php?module=WhatsAppBusinessTemplates&view=WhatsAppBusinessTemplatePopup">{vtranslate('LBL_WHATSAPP_BUSINESS_TEMPLATE', $MODULE)}</a></h3>
                        </div>
                        {vtranslate('LBL_WHATSAPP_TEMPLATE_NOTE', $MODULE)}
                    </div>
                	<div class="features-wrapper-section features-wrapper-section-1" style="width: 20%;">
                		<div class="features-wrapper-section-box">
                			<h3 style="text-align: center;"><a href="index.php?module=WhatsAppBusinessTemplates&view=Edit">{vtranslate('LBL_INTERNAL_TEMPLATE', $MODULE)}</a></h3>
                		</div>
                        {vtranslate('LBL_REGULAR_TEMPLATE_NOTE', $MODULE)}
                	</div>
               	</div>
            </div>
        </div>
    </div>
</body>
</html>
{literal}
<script type="text/javascript">
    $(document).ready(function() {
       $('.app-footer') .remove();
    });
</script>
{/literal}