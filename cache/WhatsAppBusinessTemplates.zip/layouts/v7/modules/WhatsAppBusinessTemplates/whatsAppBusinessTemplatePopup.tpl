{*+**********************************************************************************
* The contents of this file are subject to the vtiger CRM Public License Version 1.1
* ("License"); You may not use this file except in compliance with the License
* The Original Code is: vtiger CRM Open Source
* The Initial Developer of the Original Code is vtiger.
* Portions created by vtiger are Copyright (C) vtiger.
* All Rights Reserved.
************************************************************************************}
{strip}
	<div class="viewContent">
        <div class="col-sm-12 col-xs-12 content-area ">
        	<div class="editViewBody">
				<div class="editViewPageDiv " id="editViewContent" >
					<div class="col-lg-12 col-sm-12 col-xs-12">
						<div class="contents">
							<form name="whatsAppBusinessEditView" id="whatsAppBusinessEditView">
								<input type="hidden" name="recordId" id="recordId" value="{$WHATSAPP_TEMPLATE_DATA.recordId}">
								<div class="clearfix">
									<div class="col-xs-8">
										<h4>{vtranslate('LBL_CREATE_TEMPLATE_MESSAGE', $MODULENAME)}</h4>
									</div>
									<div class="col-xs-4">
										<div class="textAlignCenter col-lg-12 col-md-12 col-sm-12">
											<div class="btn-group pull-right" style="display: flex;align-items: center;">
												<button class="btn btn-success" id="savePreviewTemplate" type="button" style="margin-right:10px;">
													<strong>{vtranslate('LBL_SAVE_AND_PREVIEW', $MODULENAME)}</strong>
												</button>

												<button class="btn btn-success" id="saveWhatsAppBusiness" type="button">
													<strong>{vtranslate('LBL_SAVE_AND_SEND', $MODULENAME)}</strong>
												</button>
												
												<a class="cancelLink" href="javascript:history.back()" type="reset">{vtranslate('LBL_CANCEL',$MODULENAME)}</a>
											</div>
										</div>
									</div>
								</div><hr>

								<div class="flex-container">
									<div style="width:70%" class="flex-child">
										<table class="table editview-table no-border" style="width:70%;">
											<tbody>
												<tr>
													<td class="fieldLabel alignMiddle">{vtranslate('LBL_TEMPLATE_NAME', $MODULENAME)}<span class="redColor">*</span></td>
													<td class="fieldValue">
														<span class="mainspan templateNameSpan">
															<span class="textBoxCharacterSpan" id="templateNameCharacterCount">0/512</span>
															<input class="inputElement" type="text" name="templateName" id="templateName" value="{$WHATSAPP_TEMPLATE_DATA.templateName}" placeholder="{vtranslate('LBL_ENTER_TEMPLATE_NAME', $MODULENAME)}" maxlength="512" {if $WHATSAPP_TEMPLATE_DATA.whatsAppBusinessTemplateId neq ''} readonly="true"{/if}>
														</span>
													</td>
												</tr>
												<tr>
													<td class="fieldLabel alignMiddle">{vtranslate('LBL_CATEGORY', $MODULENAME)}<span class="redColor">*</span></td>
													<td class="fieldValue">
														<select class="inputElement select2 select2-offscreen" id="templateCategory" name="templateCategory" data-fieldname="templateCategory">
															<option value="">{vtranslate('LBL_SELECT_AN_OPTION',$MODULENAME)}</option>
															<option value="MARKETING" {if $WHATSAPP_TEMPLATE_DATA.templateCategory eq 'MARKETING'} selected{/if}>{vtranslate('LBL_MARKETING',$MODULENAME)}</option>
															<option value="UTILITY" {if $WHATSAPP_TEMPLATE_DATA.templateCategory eq 'UTILITY'} selected{/if}>{vtranslate('LBL_UTILITY',$MODULENAME)}</option>
														</select>
													</td>
												</tr>
												<tr>
													<td class="fieldLabel alignMiddle">{vtranslate('LBL_LANGUAGE', $MODULENAME)}<span class="redColor">*</span></td>
													<td class="fieldValue">
														<select class="inputElement select2 select2-offscreen" id="templateLanguage" name="templateLanguage" {if $WHATSAPP_TEMPLATE_DATA.whatsAppBusinessTemplateId neq ''} disabled="true"{/if}>
															{$LANGUAGES_LIST}
														</select>
													</td> 
												</tr>
												<tr {if $WHATSAPP_TEMPLATE_DATA.whatsAppBusinessTemplateId eq ''} style="display: none;"{/if}>
													<td class="fieldLabel alignMiddle">{vtranslate('LBL_WHATSAPP_TEMPLATE_ID', $MODULENAME)}</td>
													<td class="fieldValue">
														<input class="inputElement" type="text" name="whatsAppBusinessTemplateId" id="whatsAppBusinessTemplateId" value="{$WHATSAPP_TEMPLATE_DATA.whatsAppBusinessTemplateId}" readonly="true">
													</td>
												</tr>
												<tr {if $WHATSAPP_TEMPLATE_DATA.whatsAppBusinessTemplateId eq ''} style="display: none;"{/if}>
													<td class="fieldLabel alignMiddle">{vtranslate('LBL_WHATSAPP_TEMPLATE_STATUS', $MODULENAME)}</td>
													<td class="fieldValue">
														<input class="inputElement" type="text" name="whatsAppTemplateStatus" id="whatsAppTemplateStatus" value="{$WHATSAPP_TEMPLATE_DATA.whatsAppTemplateStatus}" readonly="true">
													</td>
												</tr>
											</tbody>
										</table>
										<hr>
										<table class="table editview-table no-border" style="width:70%;">
											<tbody>
												<tr colspan="2">
													<td class="fieldLabel alignMiddle"><h4>{vtranslate('LBL_HEADER', $MODULENAME)} <span>({vtranslate('LBL_OPTIONAL', $MODULENAME)})</span></h4></td>
												</tr>
												<tr colspan="2">
													<td class="fieldLabel alignMiddle"><span>{vtranslate('LBL_HEADER_DESCRIPTION', $MODULENAME)}</span></td>
												</tr>
												<tr colspan="2">
													<td class="fieldValue">
														<select class="inputElement select2 select2-offscreen" id="headerType" name="headerType">
															<option value="TEXT" {if $WHATSAPP_TEMPLATE_DATA.headerType eq 'TEXT'} selected{/if}>{vtranslate('LBL_TEXT', $MODULENAME)}</option>
															<option value="MEDIA" {if $WHATSAPP_TEMPLATE_DATA.headerType eq 'MEDIA'} selected{/if}>{vtranslate('LBL_MEDIA', $MODULENAME)}</option>
														</select>
													</td>
												</tr>

												<tr colspan="2">
													<td class="fieldValue">
														<span class="mainspan">
															<span class="textBoxCharacterSpan" id="headerTextCount">0/60</span>
															<input class="inputElement" type="text" name="headerText" id="headerText" value="{$WHATSAPP_TEMPLATE_DATA.headerText}" placeholder="{vtranslate('LBL_ENTER_HEADER_TEXT', $MODULENAME)}" maxlength="60">
														</span>
													</td>
												</tr>
												<tr colspan="2" class="mediaTypeRadioButton" style="display:none;">
													<td class="fieldValue">
														<span class="mediaTypeRadio">
															<input type="radio" name="mediaType[]" id="mediaType" value="IMAGE" {if $WHATSAPP_TEMPLATE_DATA.mediaType eq 'IMAGE'} checked{/if}>Image
														</span>
														<span class="mediaTypeRadio">
															<input type="radio" name="mediaType[]" id="mediaType" value="VIDEO" {if $WHATSAPP_TEMPLATE_DATA.mediaType eq 'VIDEO'} checked{/if}>Video
														</span>
														<span class="mediaTypeRadio">
															<input type="radio" name="mediaType[]" id="mediaType" value="DOCUMENT" {if $WHATSAPP_TEMPLATE_DATA.mediaType eq 'DOCUMENT'} checked{/if}>Document 
														</span>
													</td> 
												</tr>
												<tr class="uploadMedia" style="display:none;">
													<td class="fieldValue">
														<span class="uploadMediaSpan">{vtranslate('LBL_UPLOAD_MEDIA', $MODULENAME)}</span>
														<input type="hidden" name="headerMediaData" id="headerMediaData" value="">
														<input type="hidden" name="headerMediaFileLength" id="headerMediaFileLength" value="">
														<input type="hidden" name="headerMediaFileType" id="headerMediaFileType" value="">
														<input type="hidden" name="headerMediaPath" id="headerMediaPath" value="{$WHATSAPP_TEMPLATE_DATA.headerMediaPath}">
														<div class="fileUploadContainer text-left">
															<div class="fileUploadBtn btn btn-sm btn-primary">
																<span><i class="fa fa-laptop"></i> {vtranslate('LBL_ATTACH_FILES', $MODULE)}</span>
																<input class="inputElement" type="file" name="uploadHeaderMedia" id="uploadHeaderMedia">
															</div>
															<div class="uploadedFileDetails">
																<div class="uploadedFileSize"></div>
																<div class="uploadedFileName">
																	[{$WHATSAPP_TEMPLATE_DATA.fileName}]
																</div>
																{if $WHATSAPP_TEMPLATE_DATA.fileName neq ''}
																	<span class="col-lg-1"><input type="button" id="deleteFile" value="{vtranslate('LBL_DELETE', $MODULENAME)}" class="headerImageDelete"></span>
																{/if}
															</div>
														</div>
													</td>
												</tr>

												<tr colspan="2">
													<td>
														<button name="btnAddHeaderVariable" id="btnAddHeaderVariable" class="btn btn-success" type="button">{vtranslate('LBL_ADD_VARIABLE', $MODULENAME)}</button>
													</td>
												</tr>

												<tr colspan="2" class="headerContentLabel" style="display:none;">
													<td>
														{vtranslate('LBL_HEADER_CONTENT', $MODULENAME)}
													</td>
												</tr>

												<tr class="headerVariableBlock" style="display:none;">
													<td class="fieldValue">
														<span>{vtranslate('LBL_HEADER_VARIABLE_1', $MODULENAME)}</span>
														<input class="inputElement" type="text" name="headerVariableValue" id="headerVariableValue" value="{$WHATSAPP_TEMPLATE_DATA.headerVariableValue}" placeholder="{vtranslate('LBL_ENTER_CONTENT', $MODULENAME)}">
													</td>
												</tr>
											</tbody>
										</table>
										<hr>
										<table class="table editview-table no-border" id="tblBodyContent" style="width:70%;">
											<tbody>
												<input type="hidden" name="bodyVariableRowVal" id="bodyVariableRowVal" value="0">
												<tr colspan="2">
													<td><h4>{vtranslate('LBL_BODY', $MODULENAME)}</h4></td>
												</tr>

												<tr colspan="2">
													<td>{vtranslate('LBL_BODY_DESCRIPTION', $MODULENAME)}<span class="redColor">*</span></td>
												</tr>
												<tr colspan="2">
													<td>
														<textarea name="bodyText" id="bodyText" rows="5" cols="78" maxlength="1024" style="padding: 3px 8px;">{$WHATSAPP_TEMPLATE_DATA.bodyText}</textarea>
														<span id="bodyTextCount">0/1024</span>
													</td>
												</tr>	
												<tr colspan="2">
													<td>
														<button name="btnAddBodyVariable" id="btnAddBodyVariable" class="btn btn-success" type="button">{vtranslate('LBL_ADD_VARIABLE', $MODULENAME)}</button>
													</td>
												</tr>
											</tbody>
										</table>
										<hr>
										<table class="table editview-table no-border" style="width:70%;">
											<tbody>
												<tr colspan="2">
													<td><h4>{vtranslate('LBL_FOOTER', $MODULENAME)}<span>({vtranslate('LBL_OPTIONAL', $MODULENAME)})</span></h4></td>
												</tr>
												<tr colspan="2">
													<td>{vtranslate('LBL_FOOTER_DESCRIPTION', $MODULENAME)}</td>
												</tr>

												<tr colspan="2">
													<td class="fieldValue">
														<span class="mainspan">
															<span class="textBoxCharacterSpan" id="footerTextCount">0/60</span>
															<input class="inputElement" type="text" name="footerText" id="footerText" value="{$WHATSAPP_TEMPLATE_DATA.footerText}" placeholder="{vtranslate('LBL_ENTER_FOOTER_TEXT', $MODULENAME)}" maxlength="60">
														</span>
													</td>
												</tr>
											</tbody>
										</table>
										<hr>
										<table class="table editview-table no-border" style="width:70%;">
											<input type="hidden" name="customButtonCnt" id="customButtonCnt" value="0">
											<input type="hidden" name="vistWebsiteButtonCnt" id="vistWebsiteButtonCnt" value="0">
											<input type="hidden" name="callPhoneNumberButtonCnt" id="callPhoneNumberButtonCnt" value="0">
											<input type="hidden" name="copyOfferCodeButtonCnt" id="copyOfferCodeButtonCnt" value="0">
											<tbody>
												<tr colspan="2">
													<td><h4>{vtranslate('LBL_BUTTONS', $MODULENAME)}<span>({vtranslate('LBL_OPTIONAL', $MODULENAME)})</span></h4></td>
												</tr>
												<tr colspan="2">
													<td>{vtranslate('LBL_BUTTONS_DESCRIPTION', $MODULENAME)}</td>
												</tr>

												<tr colspan="2">
													<td class="fieldValue">
														<select class="inputElement select2 select2-offscreen" id="buttonType" name="buttonType">
															<option value="">{vtranslate('LBL_SELECT_AN_OPTION',$MODULENAME)}</option>
															<optgroup label="{vtranslate('LBL_QUICK_REPLAY_BUTTONS', $MODULENAME)}">
																<option value="quick_replay_button">{vtranslate('LBL_CUSTOM', $MODULENAME)}</option>
															</optgroup>
															<optgroup label="{vtranslate('LBL_CALL_TO_ACTIONS_BUTTONS', $MODULENAME)}">
																<option value="Visit Website">{vtranslate('LBL_VISIT_WEBSITE', $MODULENAME)}</option>
																<option value="Call Phone Number">{vtranslate('LBL_CALL_PHONE_NUMBER', $MODULENAME)}</option>
																<option value="Copy Offer Code">{vtranslate('LBL_COPY_OFFER_CODE', $MODULENAME)}</option>
															</optgroup>
														</select>
													</td>
												</tr>

												<tr class="dynamicButton">
													<table id="dynamicButton">
														<tr>
															<td>
															</td>
														</tr>
													</table>
												</tr>
											</tbody>
										</table>
										<div class="row clearfix"></div>
									</div>
									<div class="flex-child previewDiv" {if $WHATSAPP_TEMPLATE_DATA.recordId eq ''} style="width:30%;display: none;" {else} style="width:30%;"{/if}>
										<center><b><h5>{vtranslate('LBL_WHATSAPP_TEMPLATE_PREVIEW', $MODULE)}</h5></b></center>
										{$PREVIEW_CONTENT}
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
			<div class="modal-overlay-footer" style="border-left: none !important;">
		        <div class="row clearfix">
		            <div class="textAlignCenter col-lg-12 col-md-12 col-sm-12 ">
						<button class="btn btn-success" id="savePreviewTemplate" type="button" style="margin-right:10px;">
							<strong>{vtranslate('LBL_SAVE_AND_PREVIEW', $MODULENAME)}</strong>
						</button>

						<button class="btn btn-success" id="saveWhatsAppBusiness" type="button">
							<strong>{vtranslate('LBL_SAVE_AND_SEND', $MODULENAME)}</strong>
						</button>
						
						<a class="cancelLink" href="javascript:history.back()" type="reset">{vtranslate('LBL_CANCEL',$MODULENAME)}</a>
					</div>
		        </div>
		    </div>
		</div>
	</div>
{literal}
<script>
	var bodyVariableValue = {/literal}{$WHATSAPP_TEMPLATE_DATA.bodyVariableValue|@json_encode}{literal};
	var buttonsData = {/literal}{$WHATSAPP_TEMPLATE_DATA.buttonsData|@json_encode}{literal};
	$(document).ready(function() {
       $('.app-footer') .remove();
    });
</script>
{/literal}
{/strip}