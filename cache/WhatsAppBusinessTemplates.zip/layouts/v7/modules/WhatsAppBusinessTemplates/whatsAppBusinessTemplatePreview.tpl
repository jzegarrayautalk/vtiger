<link rel="stylesheet" type="text/css" href="layouts/v7/modules/WhatsAppBusinessTemplates/resources/css/WhatsAppTemplatePreview.css?v=4">
<div class="previewModelBody">
	<div class="clearfix">
		<div class="preview_box">
    		<div class="preview_header">
    			<div class="preview_side_box"></div>
        		{$HEADER}
        		<p>{$BODY|escape:'htmlentitydecode'}</p>
        		<div class="preview_footer_time">
            		<p class="preview_footer">{$FOOTER}</p>
            		<p class="preview_time">{$PREVIEW_TIME}</p>
        		</div>
        	</div>
    		<div class="preview_body">
    			{$BUTTONDATA}
    		</div>
		</div>
	</div>
</div>